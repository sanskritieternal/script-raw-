# 460_ai_careers_documentary_stories: "AI Careers" -- Topic Preset

> Domain: AI Careers | Sub-type: Documentary Stories
> Category: Careers_Workplace | Topic Folder: ai_careers
> Subject Preset: CAT_Careers_Workplace.md
> Niche Preset: NICHE_460_ai_careers.md
> Visual Style ID: 460

---

## Q2: Target Audience
**Default:** General Public
## Q3: Primary Story Angle
**Default:** Documentary Stories
## Q4: Content Depth Level
**Default:** Deep Analysis
## Q5: Visual/Media Priority
**Default:** Heavy
## Q6: Interview/Documentation Segments
**Default:** Quotes Only
## Q7: Content Sensitivity Level
**Default:** Moderate
## Q8: Legal/Accuracy Concern
**Default:** High
## Q9: Subject Focus
**Default:** Topic-Driven
## Q10: Contested Facts Included
**Default:** No contested claims
## Q11: Expertise Level Required
**Default:** General knowledge
## Q12: Comparative Content
**Default:** No comparisons
## Q13: Monetization Priority
**Default:** Important
## Q14: Total Duration
**Default:** 600 seconds
## Q15: Visual Style Primary
**Default:** Futuristic Tech Editorial
## Q16: Voiceover Approach
**Default:** Engaging Storytelling
## Q17: Delivery Format
**Default:** Single video
## Q18: Primary Language
**Default:** EN
## Q19: Additional Languages
**Default:** None
## Q20: On-Screen Text Strategy
**Default:** Moderate
## Q21: Graphics Requirement
**Default:** Essential
## Q22: Ending Tone
**Default:** Reflective/Thoughtful
## Q23: Accuracy Priority
**Default:** Mixed audience
## Q24: Source Quality Requirements
**Default:** Critical
## Q25: Update Frequency
**Default:** As-needed
## Q26: Platform Distribution
**Default:** YouTube + Shorts/Reels
## Q27: Production Quality Level
**Default:** Premium
## Q28: Audience Geographic Focus
**Default:** Global
## Q29: Factual Verification Timeline
**Default:** Standard (3-7 days)
## Q30: Expert/Access
**Default:** No interviews
## Q31: Controversial Content Level
**Default:** No controversial claims
## Q32: Comparative/Fairness Level
**Default:** No comparisons
## Q33: Current Events Included
**Default:** Historical only
## Q34: Bias Prevention Strategy
**Default:** Acknowledge limitations, show multiple perspectives, cite sources
## Q35: Sponsored Content
**Default:** No sponsorships
## Q36: Monetization Revenue Model
**Default:** AdSense revenue
## Q37: Series/Playlist Strategy
**Default:** Themed playlist
## Q38: SEO Keyword Priority
**Default:** Specific topic/subject names
## Q39: Content Warning/Disclaimer Needed
**Default:** Educational disclaimer
## Q40: Video Generation Method
**Default:** Data visualization + narration
## Q41: Content Safety Level
**Default:** Standard
## Q42: Scene Duration Strategy
**Default:** FIXED 8-SECOND

---

## Visual Style (MASTER_VISUAL_STYLE.md row 460)

| Field | Value |
|---|---|
| Primary Visual Style | Futuristic Tech Editorial |
| Visual Language | clean cinematic UI + macro hardware |
| Palette | deep navy / electric cyan / violet |
| Lighting | cool rim light, controlled contrast |
| Camera / Lens | 35mm + macro + screen inserts |
| Motion | controlled cuts, purposeful camera movement |
| Thumbnail Direction | hero device/system + high contrast UI/data element |
| AI Prompt Keywords | futuristic technology editorial, photoreal hardware, cinematic UI, cool rim light, premium commercial realism |
| Avoid | generic sci-fi clutter, fake UI text, impossible hardware details |

