# 002_history_mystery_documentary_history_origins: "History / Mystery Documentary" -- Topic Preset

> Domain: History / Mystery Documentary | Sub-type: History & Origins
> Category: Ancient_Civilizations | Topic Folder: history_mystery_documentary
> Subject Preset: CAT_Ancient_Civilizations.md
> Niche Preset: NICHE_002_history_mystery_documentary.md
> Visual Style ID: 2

---

## Q2: Target Audience
**Default:** General Public
## Q3: Primary Story Angle
**Default:** History & Origins
## Q4: Content Depth Level
**Default:** Moderate
## Q5: Visual/Media Priority
**Default:** Moderate
## Q6: Interview/Documentation Segments
**Default:** Archival Footage
## Q7: Content Sensitivity Level
**Default:** Moderate
## Q8: Legal/Accuracy Concern
**Default:** Moderate
## Q9: Subject Focus
**Default:** Topic-Driven
## Q10: Contested Facts Included
**Default:** No contested claims
## Q11: Expertise Level Required
**Default:** General knowledge
## Q12: Comparative Content
**Default:** No comparisons
## Q13: Monetization Priority
**Default:** Secondary
## Q14: Total Duration
**Default:** 600 seconds
## Q15: Visual Style Primary
**Default:** Cinematic Historical Documentary
## Q16: Voiceover Approach
**Default:** Engaging Storytelling
## Q17: Delivery Format
**Default:** Single video
## Q18: Primary Language
**Default:** EN
## Q19: Additional Languages
**Default:** None
## Q20: On-Screen Text Strategy
**Default:** Moderate
## Q21: Graphics Requirement
**Default:** Important
## Q22: Ending Tone
**Default:** Reflective/Thoughtful
## Q23: Accuracy Priority
**Default:** Mixed audience
## Q24: Source Quality Requirements
**Default:** High
## Q25: Update Frequency
**Default:** As-needed
## Q26: Platform Distribution
**Default:** YouTube + Shorts/Reels
## Q27: Production Quality Level
**Default:** Premium
## Q28: Audience Geographic Focus
**Default:** Global
## Q29: Factual Verification Timeline
**Default:** Standard (3-7 days)
## Q30: Expert/Access
**Default:** No interviews
## Q31: Controversial Content Level
**Default:** No controversial claims
## Q32: Comparative/Fairness Level
**Default:** No comparisons
## Q33: Current Events Included
**Default:** Historical only
## Q34: Bias Prevention Strategy
**Default:** Acknowledge limitations, show multiple perspectives, cite sources
## Q35: Sponsored Content
**Default:** No sponsorships
## Q36: Monetization Revenue Model
**Default:** AdSense revenue
## Q37: Series/Playlist Strategy
**Default:** Themed playlist
## Q38: SEO Keyword Priority
**Default:** Specific topic/subject names
## Q39: Content Warning/Disclaimer Needed
**Default:** No warnings
## Q40: Video Generation Method
**Default:** Hybrid
## Q41: Content Safety Level
**Default:** Standard
## Q42: Scene Duration Strategy
**Default:** FIXED 8-SECOND

---

## Visual Style (MASTER_VISUAL_STYLE.md row 2)

| Field | Value |
|---|---|
| Primary Visual Style | Cinematic Historical Documentary |
| Visual Language | period reconstruction + archival textures + maps |
| Palette | earth / bronze / parchment / charcoal |
| Lighting | warm directional key, smoky atmosphere |
| Camera / Lens | 24mm environments + 50mm portraits + aerial maps |
| Motion | slow push-ins, parallax, motivated tracking |
| Thumbnail Direction | hero subject + era/location + bold negative space |
| AI Prompt Keywords | cinematic historical reconstruction, period-authentic, photoreal, tactile materials, atmospheric depth, documentary realism |
| Avoid | modern objects, generic fantasy armor, anachronisms, plastic-looking CGI |

