# 073_parenting_child_development_hidden_stories: "Parenting & Child Development" -- Topic Preset

> Domain: Parenting & Child Development | Sub-type: Hidden Stories
> Category: Childhood_Family | Topic Folder: parenting_child_development
> Subject Preset: CAT_Childhood_Family.md
> Niche Preset: NICHE_073_parenting_child_development.md
> Visual Style ID: 73

---

## Q2: Target Audience
**Default:** Children & Families
## Q3: Primary Story Angle
**Default:** Hidden Stories
## Q4: Content Depth Level
**Default:** Moderate
## Q5: Visual/Media Priority
**Default:** Moderate
## Q6: Interview/Documentation Segments
**Default:** Quotes Only
## Q7: Content Sensitivity Level
**Default:** Low
## Q8: Legal/Accuracy Concern
**Default:** Moderate
## Q9: Subject Focus
**Default:** Topic-Driven
## Q10: Contested Facts Included
**Default:** No contested claims
## Q11: Expertise Level Required
**Default:** General knowledge
## Q12: Comparative Content
**Default:** No comparisons
## Q13: Monetization Priority
**Default:** Secondary
## Q14: Total Duration
**Default:** 600 seconds
## Q15: Visual Style Primary
**Default:** Cinematic Editorial Documentary
## Q16: Voiceover Approach
**Default:** Playful Animated
## Q17: Delivery Format
**Default:** Single video
## Q18: Primary Language
**Default:** EN
## Q19: Additional Languages
**Default:** None
## Q20: On-Screen Text Strategy
**Default:** Moderate
## Q21: Graphics Requirement
**Default:** Important
## Q22: Ending Tone
**Default:** Reflective/Thoughtful
## Q23: Accuracy Priority
**Default:** Mixed audience
## Q24: Source Quality Requirements
**Default:** High
## Q25: Update Frequency
**Default:** As-needed
## Q26: Platform Distribution
**Default:** YouTube + Shorts/Reels
## Q27: Production Quality Level
**Default:** Premium
## Q28: Audience Geographic Focus
**Default:** Global
## Q29: Factual Verification Timeline
**Default:** Standard (3-7 days)
## Q30: Expert/Access
**Default:** No interviews
## Q31: Controversial Content Level
**Default:** No controversial claims
## Q32: Comparative/Fairness Level
**Default:** No comparisons
## Q33: Current Events Included
**Default:** Historical only
## Q34: Bias Prevention Strategy
**Default:** Acknowledge limitations, show multiple perspectives, cite sources
## Q35: Sponsored Content
**Default:** No sponsorships
## Q36: Monetization Revenue Model
**Default:** AdSense revenue
## Q37: Series/Playlist Strategy
**Default:** Themed playlist
## Q38: SEO Keyword Priority
**Default:** Specific topic/subject names
## Q39: Content Warning/Disclaimer Needed
**Default:** No warnings
## Q40: Video Generation Method
**Default:** Standard animation
## Q41: Content Safety Level
**Default:** Strict
## Q42: Scene Duration Strategy
**Default:** FIXED 8-SECOND

---

## Visual Style (MASTER_VISUAL_STYLE.md row 73)

| Field | Value |
|---|---|
| Primary Visual Style | Cinematic Editorial Documentary |
| Visual Language | story-driven b-roll + contextual environments + restrained graphics |
| Palette | natural neutrals + one thematic accent |
| Lighting | soft cinematic contrast with motivated practicals |
| Camera / Lens | 35mm storytelling + 50mm details + wide establishing |
| Motion | slow push-ins, parallax, motivated tracking |
| Thumbnail Direction | single hero subject + contextual environment + clear focal hierarchy |
| AI Prompt Keywords | cinematic editorial documentary, photoreal, story-driven composition, natural light, restrained graphics |
| Avoid | generic stock imagery, visual clutter, inconsistent lighting, excessive effects |

