# Topic folders

Each top-level folder below is one subject category. Inside it are niche folders; each niche folder contains `ALL_TOPICS_BY_NICHE.md` and 15 candidate angle files. The stable ID, subject category, and exact niche path are in `../NICHE_TAXONOMY.csv`.

`CAT_<Category>.md` is a subject preset in `../Categories/`. `NICHE_<ID>_<Slug>.md` is a niche preset in `../Categories/Niches/<Category>/`. Topic files show both references in their headers.

| Category | Niche folders |
|---|---:|
| [Ancient Civilizations](Ancient_Civilizations/) | 5 |
| [Careers Workplace](Careers_Workplace/) | 12 |
| [Childhood Family](Childhood_Family/) | 3 |
| [Commerce Industry](Commerce_Industry/) | 22 |
| [Computing Software](Computing_Software/) | 19 |
| [Conflict Power Exploration](Conflict_Power_Exploration/) | 6 |
| [Craft Making](Craft_Making/) | 15 |
| [Crime Safety Public Services](Crime_Safety_Public_Services/) | 10 |
| [Cultural Heritage](Cultural_Heritage/) | 19 |
| [Cybersecurity Digital Systems](Cybersecurity_Digital_Systems/) | 6 |
| [Earth Environment](Earth_Environment/) | 28 |
| [Energy Industry](Energy_Industry/) | 9 |
| [Engineering Inventions](Engineering_Inventions/) | 13 |
| [Fiction Worldbuilding](Fiction_Worldbuilding/) | 9 |
| [Film Production](Film_Production/) | 13 |
| [Finance Banking](Finance_Banking/) | 15 |
| [Food Fashion](Food_Fashion/) | 5 |
| [Future Worlds Systems](Future_Worlds_Systems/) | 13 |
| [Games Puzzles](Games_Puzzles/) | 9 |
| [Geography Places](Geography_Places/) | 14 |
| [Government Geopolitics](Government_Geopolitics/) | 8 |
| [Hindu Traditions](Hindu_Traditions/) | 15 |
| [Historical People Cultures](Historical_People_Cultures/) | 8 |
| [Home Living](Home_Living/) | 12 |
| [Hospitality Travel Systems](Hospitality_Travel_Systems/) | 4 |
| [Human Futures](Human_Futures/) | 11 |
| [Land Outdoor](Land_Outdoor/) | 4 |
| [Learning Education](Learning_Education/) | 14 |
| [Life Biology](Life_Biology/) | 27 |
| [Literature Performance](Literature_Performance/) | 15 |
| [Math Scientific Methods](Math_Scientific_Methods/) | 9 |
| [Media Formats People](Media_Formats_People/) | 5 |
| [Medicine Healthcare](Medicine_Healthcare/) | 4 |
| [Mind Wellness](Mind_Wellness/) | 5 |
| [People Communities](People_Communities/) | 12 |
| [Performance Magic](Performance_Magic/) | 3 |
| [Philosophy Spirituality](Philosophy_Spirituality/) | 5 |
| [Physical Sciences](Physical_Sciences/) | 9 |
| [Robotics AI](Robotics_AI/) | 8 |
| [Space Astronomy](Space_Astronomy/) | 7 |
| [Speculative Stories](Speculative_Stories/) | 6 |
| [Sports Adventure](Sports_Adventure/) | 9 |
| [Transport Engineering](Transport_Engineering/) | 20 |
| [Travel Experiences](Travel_Experiences/) | 9 |
| [Visual Arts Crafts](Visual_Arts_Crafts/) | 13 |
| [World Religions](World_Religions/) | 13 |

**Total:** 46 categories, 500 niche folders, 7,500 angle files.
