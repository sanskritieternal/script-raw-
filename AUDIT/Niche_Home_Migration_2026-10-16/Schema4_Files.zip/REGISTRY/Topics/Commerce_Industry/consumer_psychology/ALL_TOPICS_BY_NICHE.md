# Consumer Psychology -- All Topics

> Niche ID: 105 | 15 topic presets
> Auto-generated from MASTER_REGISTRY.md + MASTER_VISUAL_STYLE.md

---

- [Consumer Psychology (History & Origins)](./105_consumer_psychology_history_origins.md)
- [Consumer Psychology (Famous Examples)](./105_consumer_psychology_famous_examples.md)
- [Consumer Psychology (Hidden Stories)](./105_consumer_psychology_hidden_stories.md)
- [Consumer Psychology (Beginner Explainers)](./105_consumer_psychology_beginner_explainers.md)
- [Consumer Psychology (Advanced Concepts)](./105_consumer_psychology_advanced_concepts.md)
- [Consumer Psychology (Mysteries & Unsolved Cases)](./105_consumer_psychology_mysteries_unsolved_cases.md)
- [Consumer Psychology (Technology & Innovation)](./105_consumer_psychology_technology_innovation.md)
- [Consumer Psychology (People & Personalities)](./105_consumer_psychology_people_personalities.md)
- [Consumer Psychology (Major Events)](./105_consumer_psychology_major_events.md)
- [Consumer Psychology (How It Works)](./105_consumer_psychology_how_it_works.md)
- [Consumer Psychology (Rise & Fall)](./105_consumer_psychology_rise_fall.md)
- [Consumer Psychology (Then vs Now)](./105_consumer_psychology_then_vs_now.md)
- [Consumer Psychology (Future Developments)](./105_consumer_psychology_future_developments.md)
- [Consumer Psychology (Myths vs Facts)](./105_consumer_psychology_myths_vs_facts.md)
- [Consumer Psychology (Documentary Stories)](./105_consumer_psychology_documentary_stories.md)
