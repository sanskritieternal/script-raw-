# 302_entrepreneurship_people_personalities: "Entrepreneurship" -- Topic Preset

> Domain: Entrepreneurship | Sub-type: People & Personalities
> Category: Commerce_Industry | Topic Folder: entrepreneurship
> Subject Preset: CAT_Commerce_Industry.md
> Niche Preset: NICHE_302_entrepreneurship.md
> Visual Style ID: 302

---

## Q2: Target Audience
**Default:** General Public
## Q3: Primary Story Angle
**Default:** People & Personalities
## Q4: Content Depth Level
**Default:** Deep Analysis
## Q5: Visual/Media Priority
**Default:** Heavy
## Q6: Interview/Documentation Segments
**Default:** Quotes Only
## Q7: Content Sensitivity Level
**Default:** Moderate
## Q8: Legal/Accuracy Concern
**Default:** High
## Q9: Subject Focus
**Default:** Topic-Driven
## Q10: Contested Facts Included
**Default:** No contested claims
## Q11: Expertise Level Required
**Default:** General knowledge
## Q12: Comparative Content
**Default:** No comparisons
## Q13: Monetization Priority
**Default:** Important
## Q14: Total Duration
**Default:** 600 seconds
## Q15: Visual Style Primary
**Default:** Premium Business Editorial
## Q16: Voiceover Approach
**Default:** Engaging Storytelling
## Q17: Delivery Format
**Default:** Single video
## Q18: Primary Language
**Default:** EN
## Q19: Additional Languages
**Default:** None
## Q20: On-Screen Text Strategy
**Default:** Moderate
## Q21: Graphics Requirement
**Default:** Essential
## Q22: Ending Tone
**Default:** Reflective/Thoughtful
## Q23: Accuracy Priority
**Default:** Mixed audience
## Q24: Source Quality Requirements
**Default:** Critical
## Q25: Update Frequency
**Default:** As-needed
## Q26: Platform Distribution
**Default:** YouTube + Shorts/Reels
## Q27: Production Quality Level
**Default:** Premium
## Q28: Audience Geographic Focus
**Default:** Global
## Q29: Factual Verification Timeline
**Default:** Standard (3-7 days)
## Q30: Expert/Access
**Default:** No interviews
## Q31: Controversial Content Level
**Default:** No controversial claims
## Q32: Comparative/Fairness Level
**Default:** No comparisons
## Q33: Current Events Included
**Default:** Historical only
## Q34: Bias Prevention Strategy
**Default:** Acknowledge limitations, show multiple perspectives, cite sources
## Q35: Sponsored Content
**Default:** No sponsorships
## Q36: Monetization Revenue Model
**Default:** AdSense revenue
## Q37: Series/Playlist Strategy
**Default:** Themed playlist
## Q38: SEO Keyword Priority
**Default:** Specific topic/subject names
## Q39: Content Warning/Disclaimer Needed
**Default:** Educational disclaimer
## Q40: Video Generation Method
**Default:** Data visualization + narration
## Q41: Content Safety Level
**Default:** Standard
## Q42: Scene Duration Strategy
**Default:** FIXED 8-SECOND

---

## Visual Style (MASTER_VISUAL_STYLE.md row 302)

| Field | Value |
|---|---|
| Primary Visual Style | Premium Business Editorial |
| Visual Language | luxury b-roll + data overlays + polished portraits |
| Palette | charcoal / ivory / emerald / gold |
| Lighting | soft studio key, crisp highlights |
| Camera / Lens | 35mm corporate + 85mm portrait + overhead detail |
| Motion | controlled cuts, purposeful camera movement |
| Thumbnail Direction | person/object + premium environment + one data cue |
| AI Prompt Keywords | premium editorial, sophisticated office, polished portrait, cinematic commercial lighting, restrained graphics |
| Avoid | stock-photo clichés, excessive luxury flexing, cluttered dashboards |

