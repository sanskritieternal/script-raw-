# 016_motivational_stories_documentary_stories: Motivational Stories — Documentary Stories

> Subject category: Mind_Wellness
> CAT: ../CAT_016_motivational_stories.md
> NICHE: ../NICHE_016_motivational_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Documentary Stories
