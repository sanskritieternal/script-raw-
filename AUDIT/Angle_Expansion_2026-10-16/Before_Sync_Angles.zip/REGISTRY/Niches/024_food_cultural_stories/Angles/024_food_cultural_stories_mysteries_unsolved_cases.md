# 024_food_cultural_stories_mysteries_unsolved_cases: Food / Cultural Stories — Mysteries & Unsolved Cases

> Subject category: Food_Fashion
> CAT: ../CAT_024_food_cultural_stories.md
> NICHE: ../NICHE_024_food_cultural_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Mysteries & Unsolved Cases
