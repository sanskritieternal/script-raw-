# 002_history_mystery_documentary_mysteries_unsolved_cases: History / Mystery Documentary — Mysteries & Unsolved Cases

> Subject category: Ancient_Civilizations
> CAT: ../CAT_002_history_mystery_documentary.md
> NICHE: ../NICHE_002_history_mystery_documentary.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Mysteries & Unsolved Cases
