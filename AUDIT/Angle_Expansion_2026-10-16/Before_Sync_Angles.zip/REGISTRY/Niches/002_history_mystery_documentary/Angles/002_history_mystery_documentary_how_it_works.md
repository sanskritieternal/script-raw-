# 002_history_mystery_documentary_how_it_works: History / Mystery Documentary — How It Works

> Subject category: Ancient_Civilizations
> CAT: ../CAT_002_history_mystery_documentary.md
> NICHE: ../NICHE_002_history_mystery_documentary.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
