# 023_spirituality_meditation_then_vs_now: Spirituality / Meditation — Then vs Now

> Subject category: Philosophy_Spirituality
> CAT: ../CAT_023_spirituality_meditation.md
> NICHE: ../NICHE_023_spirituality_meditation.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Then vs Now
