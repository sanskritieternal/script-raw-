# 023_spirituality_meditation_how_it_works: Spirituality / Meditation — How It Works

> Subject category: Philosophy_Spirituality
> CAT: ../CAT_023_spirituality_meditation.md
> NICHE: ../NICHE_023_spirituality_meditation.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
