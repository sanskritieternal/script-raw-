# 023_spirituality_meditation_documentary_stories: Spirituality / Meditation — Documentary Stories

> Subject category: Philosophy_Spirituality
> CAT: ../CAT_023_spirituality_meditation.md
> NICHE: ../NICHE_023_spirituality_meditation.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Documentary Stories
