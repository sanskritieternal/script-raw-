# 019_ai_cinematic_short_films_famous_examples: AI Cinematic Short Films — Famous Examples

> Subject category: Film_Production
> CAT: ../CAT_019_ai_cinematic_short_films.md
> NICHE: ../NICHE_019_ai_cinematic_short_films.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Famous Examples
