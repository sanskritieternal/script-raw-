# 019_ai_cinematic_short_films_documentary_stories: AI Cinematic Short Films — Documentary Stories

> Subject category: Film_Production
> CAT: ../CAT_019_ai_cinematic_short_films.md
> NICHE: ../NICHE_019_ai_cinematic_short_films.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Documentary Stories
