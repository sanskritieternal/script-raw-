# 019_ai_cinematic_short_films_people_personalities: AI Cinematic Short Films — People & Personalities

> Subject category: Film_Production
> CAT: ../CAT_019_ai_cinematic_short_films.md
> NICHE: ../NICHE_019_ai_cinematic_short_films.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** People & Personalities
