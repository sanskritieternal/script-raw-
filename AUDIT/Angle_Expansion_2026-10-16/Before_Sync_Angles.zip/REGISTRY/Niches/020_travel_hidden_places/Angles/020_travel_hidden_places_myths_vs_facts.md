# 020_travel_hidden_places_myths_vs_facts: Travel / Hidden Places — Myths vs Facts

> Subject category: Geography_Places
> CAT: ../CAT_020_travel_hidden_places.md
> NICHE: ../NICHE_020_travel_hidden_places.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Myths vs Facts
