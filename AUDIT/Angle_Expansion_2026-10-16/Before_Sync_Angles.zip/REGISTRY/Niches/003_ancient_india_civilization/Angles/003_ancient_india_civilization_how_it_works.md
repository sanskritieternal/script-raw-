# 003_ancient_india_civilization_how_it_works: Ancient India / Civilization — How It Works

> Subject category: Ancient_Civilizations
> CAT: ../CAT_003_ancient_india_civilization.md
> NICHE: ../NICHE_003_ancient_india_civilization.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
