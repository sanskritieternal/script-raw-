# 001_ai_technology_explainers_mysteries_unsolved_cases: AI + Technology Explainers — Open Questions About AI Behavior

> Subject category: Robotics_AI
> CAT: ../CAT_001_ai_technology_explainers.md
> NICHE: ../NICHE_001_ai_technology_explainers.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Open Questions About AI Behavior

## Editorial scope

Investigate a documented behavior that researchers cannot yet fully explain; separate measured observations from hypotheses.

Example story question: Why does an AI model fail on a task it appears to understand?
