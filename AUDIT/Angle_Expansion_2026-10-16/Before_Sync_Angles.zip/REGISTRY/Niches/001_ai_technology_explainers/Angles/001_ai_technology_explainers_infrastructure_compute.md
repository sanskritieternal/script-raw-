# 001_ai_technology_explainers_infrastructure_compute: AI + Technology Explainers — The Compute and Energy Behind AI

> Subject category: Robotics_AI
> CAT: ../CAT_001_ai_technology_explainers.md
> NICHE: ../NICHE_001_ai_technology_explainers.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** The Compute and Energy Behind AI

## Editorial scope

Explain the infrastructure of one AI workload using sourced figures and clear system boundaries.

Example story question: What resources does a defined AI workload actually require?
