# 001_ai_technology_explainers_people_personalities: AI + Technology Explainers — Decisions That Shaped AI Development

> Subject category: Robotics_AI
> CAT: ../CAT_001_ai_technology_explainers.md
> NICHE: ../NICHE_001_ai_technology_explainers.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Decisions That Shaped AI Development

## Editorial scope

Follow a documented decision by a person or team and its technical or social consequences without relying on personality mythology.

Example story question: How did one research decision change the direction of AI?
