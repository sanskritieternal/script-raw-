# 001_ai_technology_explainers_history_origins: AI + Technology Explainers — How AI Ideas Became Working Systems

> Subject category: Robotics_AI
> CAT: ../CAT_001_ai_technology_explainers.md
> NICHE: ../NICHE_001_ai_technology_explainers.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How AI Ideas Became Working Systems

## Editorial scope

Trace one AI idea from its original problem through the methods and conditions that made it practical. Identify what changed at each step.

Example story question: What made a once impractical AI idea usable?
