# 001_ai_technology_explainers_then_vs_now: AI + Technology Explainers — How AI Capabilities Are Measured Over Time

> Subject category: Robotics_AI
> CAT: ../CAT_001_ai_technology_explainers.md
> NICHE: ../NICHE_001_ai_technology_explainers.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How AI Capabilities Are Measured Over Time

## Editorial scope

Compare past and present systems on the same task while accounting for changing benchmarks, data, and costs.

Example story question: How much has AI improved on a clearly defined task?
