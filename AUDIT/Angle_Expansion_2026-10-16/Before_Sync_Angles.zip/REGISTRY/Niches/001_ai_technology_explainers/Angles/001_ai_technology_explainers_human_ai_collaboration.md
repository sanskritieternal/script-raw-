# 001_ai_technology_explainers_human_ai_collaboration: AI + Technology Explainers — Where Human Judgment Still Enters AI Work

> Subject category: Robotics_AI
> CAT: ../CAT_001_ai_technology_explainers.md
> NICHE: ../NICHE_001_ai_technology_explainers.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Where Human Judgment Still Enters AI Work

## Editorial scope

Map the decisions, review steps, and accountability in one human-plus-AI workflow.

Example story question: Which decisions in an AI-assisted workflow still require a person?
