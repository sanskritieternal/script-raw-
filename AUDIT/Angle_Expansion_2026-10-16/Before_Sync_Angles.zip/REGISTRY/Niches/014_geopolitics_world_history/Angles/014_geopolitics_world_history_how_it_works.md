# 014_geopolitics_world_history_how_it_works: Geopolitics / World History — How It Works

> Subject category: Government_Geopolitics
> CAT: ../CAT_014_geopolitics_world_history.md
> NICHE: ../NICHE_014_geopolitics_world_history.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
