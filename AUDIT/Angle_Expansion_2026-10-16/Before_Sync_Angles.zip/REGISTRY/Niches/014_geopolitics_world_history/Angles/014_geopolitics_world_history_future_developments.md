# 014_geopolitics_world_history_future_developments: Geopolitics / World History — Future Developments

> Subject category: Government_Geopolitics
> CAT: ../CAT_014_geopolitics_world_history.md
> NICHE: ../NICHE_014_geopolitics_world_history.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Future Developments
