# 014_geopolitics_world_history_famous_examples: Geopolitics / World History — Famous Examples

> Subject category: Government_Geopolitics
> CAT: ../CAT_014_geopolitics_world_history.md
> NICHE: ../NICHE_014_geopolitics_world_history.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Famous Examples
