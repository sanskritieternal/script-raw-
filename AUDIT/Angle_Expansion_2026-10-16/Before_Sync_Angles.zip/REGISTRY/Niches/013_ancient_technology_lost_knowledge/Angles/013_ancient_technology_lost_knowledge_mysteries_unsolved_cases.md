# 013_ancient_technology_lost_knowledge_mysteries_unsolved_cases: Ancient Technology / Lost Knowledge — Mysteries & Unsolved Cases

> Subject category: Engineering_Inventions
> CAT: ../CAT_013_ancient_technology_lost_knowledge.md
> NICHE: ../NICHE_013_ancient_technology_lost_knowledge.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Mysteries & Unsolved Cases
