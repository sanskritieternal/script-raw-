# 013_ancient_technology_lost_knowledge_technology_innovation: Ancient Technology / Lost Knowledge — Technology & Innovation

> Subject category: Engineering_Inventions
> CAT: ../CAT_013_ancient_technology_lost_knowledge.md
> NICHE: ../NICHE_013_ancient_technology_lost_knowledge.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Technology & Innovation
