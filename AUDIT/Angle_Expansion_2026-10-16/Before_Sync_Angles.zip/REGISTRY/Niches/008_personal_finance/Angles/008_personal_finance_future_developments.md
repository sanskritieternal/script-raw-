# 008_personal_finance_future_developments: Personal Finance — Future Developments

> Subject category: Finance_Banking
> CAT: ../CAT_008_personal_finance.md
> NICHE: ../NICHE_008_personal_finance.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Future Developments
