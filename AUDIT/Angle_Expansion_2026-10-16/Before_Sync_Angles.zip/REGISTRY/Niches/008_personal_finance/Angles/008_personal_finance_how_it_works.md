# 008_personal_finance_how_it_works: Personal Finance — How It Works

> Subject category: Finance_Banking
> CAT: ../CAT_008_personal_finance.md
> NICHE: ../NICHE_008_personal_finance.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
