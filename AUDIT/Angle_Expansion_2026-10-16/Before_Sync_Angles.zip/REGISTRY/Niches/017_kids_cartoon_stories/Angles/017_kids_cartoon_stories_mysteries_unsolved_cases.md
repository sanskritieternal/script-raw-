# 017_kids_cartoon_stories_mysteries_unsolved_cases: Kids Cartoon Stories — Mysteries & Unsolved Cases

> Subject category: Childhood_Family
> CAT: ../CAT_017_kids_cartoon_stories.md
> NICHE: ../NICHE_017_kids_cartoon_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Mysteries & Unsolved Cases
