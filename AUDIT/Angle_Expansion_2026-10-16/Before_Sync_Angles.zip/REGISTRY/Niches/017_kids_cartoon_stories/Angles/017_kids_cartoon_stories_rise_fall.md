# 017_kids_cartoon_stories_rise_fall: Kids Cartoon Stories — Rise & Fall

> Subject category: Childhood_Family
> CAT: ../CAT_017_kids_cartoon_stories.md
> NICHE: ../NICHE_017_kids_cartoon_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Rise & Fall
