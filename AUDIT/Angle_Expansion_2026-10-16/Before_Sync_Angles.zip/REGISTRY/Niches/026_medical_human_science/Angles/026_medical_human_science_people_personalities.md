# 026_medical_human_science_people_personalities: Medical & Human Science — People & Personalities

> Subject category: Life_Biology
> CAT: ../CAT_026_medical_human_science.md
> NICHE: ../NICHE_026_medical_human_science.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** People & Personalities
