# 026_medical_human_science_how_it_works: Medical & Human Science — How It Works

> Subject category: Life_Biology
> CAT: ../CAT_026_medical_human_science.md
> NICHE: ../NICHE_026_medical_human_science.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
