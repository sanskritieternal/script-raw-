# 010_true_crime_documentary_then_vs_now: True Crime Documentary — Then vs Now

> Subject category: Crime_Safety_Public_Services
> CAT: ../CAT_010_true_crime_documentary.md
> NICHE: ../NICHE_010_true_crime_documentary.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Then vs Now
