# 010_true_crime_documentary_people_personalities: True Crime Documentary — People & Personalities

> Subject category: Crime_Safety_Public_Services
> CAT: ../CAT_010_true_crime_documentary.md
> NICHE: ../NICHE_010_true_crime_documentary.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** People & Personalities
