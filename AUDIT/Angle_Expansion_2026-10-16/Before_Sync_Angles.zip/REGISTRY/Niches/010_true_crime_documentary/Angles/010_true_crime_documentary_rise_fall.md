# 010_true_crime_documentary_rise_fall: True Crime Documentary — Rise & Fall

> Subject category: Crime_Safety_Public_Services
> CAT: ../CAT_010_true_crime_documentary.md
> NICHE: ../NICHE_010_true_crime_documentary.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Rise & Fall
