# 007_ai_tools_ai_tutorials_how_it_works: AI Tools / AI Tutorials — How It Works

> Subject category: Robotics_AI
> CAT: ../CAT_007_ai_tools_ai_tutorials.md
> NICHE: ../NICHE_007_ai_tools_ai_tutorials.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
