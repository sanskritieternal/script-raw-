# 007_ai_tools_ai_tutorials_hidden_stories: AI Tools / AI Tutorials — Hidden Stories

> Subject category: Robotics_AI
> CAT: ../CAT_007_ai_tools_ai_tutorials.md
> NICHE: ../NICHE_007_ai_tools_ai_tutorials.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Hidden Stories
