# 007_ai_tools_ai_tutorials_mysteries_unsolved_cases: AI Tools / AI Tutorials — Mysteries & Unsolved Cases

> Subject category: Robotics_AI
> CAT: ../CAT_007_ai_tools_ai_tutorials.md
> NICHE: ../NICHE_007_ai_tools_ai_tutorials.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Mysteries & Unsolved Cases
