# 007_ai_tools_ai_tutorials_then_vs_now: AI Tools / AI Tutorials — Then vs Now

> Subject category: Robotics_AI
> CAT: ../CAT_007_ai_tools_ai_tutorials.md
> NICHE: ../NICHE_007_ai_tools_ai_tutorials.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Then vs Now
