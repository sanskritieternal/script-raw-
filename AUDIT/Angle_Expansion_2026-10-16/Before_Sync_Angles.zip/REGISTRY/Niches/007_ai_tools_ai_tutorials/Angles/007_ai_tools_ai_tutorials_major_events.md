# 007_ai_tools_ai_tutorials_major_events: AI Tools / AI Tutorials — Major Events

> Subject category: Robotics_AI
> CAT: ../CAT_007_ai_tools_ai_tutorials.md
> NICHE: ../NICHE_007_ai_tools_ai_tutorials.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Major Events
