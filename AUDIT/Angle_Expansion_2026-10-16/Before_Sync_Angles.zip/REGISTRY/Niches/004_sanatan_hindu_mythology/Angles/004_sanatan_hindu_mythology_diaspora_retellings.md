# 004_sanatan_hindu_mythology_diaspora_retellings: Sanatan / Hindu Mythology — A Story Carried Across Places

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Story Carried Across Places

## Editorial scope

Examine a documented retelling in a diaspora community, centering that community's voice and avoiding assumptions of a uniform experience.

Example story question: How does a community adapt a familiar story in a new place?
