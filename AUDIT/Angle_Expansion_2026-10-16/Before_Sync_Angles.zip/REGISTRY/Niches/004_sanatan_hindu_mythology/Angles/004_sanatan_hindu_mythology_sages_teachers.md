# 004_sanatan_hindu_mythology_sages_teachers: Sanatan / Hindu Mythology — Sages as Narrative Agents

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Sages as Narrative Agents

## Editorial scope

Examine how a named sage or teacher affects a story's choices, transmission, or moral argument in a specific source.

Example story question: What role does a sage play in the turning point of one narrative?
