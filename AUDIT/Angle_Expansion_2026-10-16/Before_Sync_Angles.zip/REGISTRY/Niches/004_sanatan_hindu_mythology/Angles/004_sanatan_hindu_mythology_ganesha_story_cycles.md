# 004_sanatan_hindu_mythology_ganesha_story_cycles: Sanatan / Hindu Mythology — A Ganesha Story and Its Variants

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Ganesha Story and Its Variants

## Editorial scope

Compare one Ganesha-centered narrative in named tellings, rather than collapsing distinct stories into a single origin.

Example story question: Which details of a Ganesha story vary by source?
