# 004_sanatan_hindu_mythology_myths_vs_facts: Sanatan / Hindu Mythology — Belief, Text, and Historical Evidence

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Belief, Text, and Historical Evidence

## Editorial scope

Separate what a source narrates, what practitioners believe, and what independent historical evidence can establish about one claim.

Example story question: Which parts of a popular claim come from text, belief, or historical evidence?
