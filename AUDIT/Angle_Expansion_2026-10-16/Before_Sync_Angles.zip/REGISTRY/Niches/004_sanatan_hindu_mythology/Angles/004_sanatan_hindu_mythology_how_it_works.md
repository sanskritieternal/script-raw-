# 004_sanatan_hindu_mythology_how_it_works: Sanatan / Hindu Mythology — How to Read a Sacred Episode in Context

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How to Read a Sacred Episode in Context

## Editorial scope

Show how source, speaker, audience, genre, and surrounding chapters affect the interpretation of one episode.

Example story question: What changes when an episode is read in its full context?
