# 004_sanatan_hindu_mythology_sacred_places_in_story: Sanatan / Hindu Mythology — A Place as a Narrative Setting

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Place as a Narrative Setting

## Editorial scope

Study how a named place functions within a sourced story, keeping narrative geography separate from historical site claims.

Example story question: What does a place contribute to the meaning of one episode?
