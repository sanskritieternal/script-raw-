# 004_sanatan_hindu_mythology_cycles_time: Sanatan / Hindu Mythology — How Cyclical Time Shapes a Story

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How Cyclical Time Shapes a Story

## Editorial scope

Explain one use of yuga, kalpa, or another time frame within a named story without converting it into an unsupported historical date.

Example story question: What does a cycle of time do in this narrative?
