# 004_sanatan_hindu_mythology_sacred_worlds: Sanatan / Hindu Mythology — Journeys Between Narrative Worlds

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Journeys Between Narrative Worlds

## Editorial scope

Follow one journey through celestial, earthly, or other realms in a named source and explain its narrative purpose.

Example story question: Why does a character cross between worlds in this story?
