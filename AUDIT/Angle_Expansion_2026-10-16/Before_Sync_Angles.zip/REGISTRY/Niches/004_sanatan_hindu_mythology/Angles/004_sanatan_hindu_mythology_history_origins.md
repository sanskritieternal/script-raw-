# 004_sanatan_hindu_mythology_history_origins: Sanatan / Hindu Mythology — How Sacred Stories Took Shape

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How Sacred Stories Took Shape

## Editorial scope

Trace the transmission of one narrative across a named text, place, or community; distinguish the story's setting from evidence about when a version was recorded.

Example story question: How did one sacred story acquire its familiar form?
