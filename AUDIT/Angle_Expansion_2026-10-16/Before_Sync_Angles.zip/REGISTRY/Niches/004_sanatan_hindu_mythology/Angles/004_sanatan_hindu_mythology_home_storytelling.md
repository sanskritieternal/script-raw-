# 004_sanatan_hindu_mythology_home_storytelling: Sanatan / Hindu Mythology — Stories Passed Through Everyday Practice

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Stories Passed Through Everyday Practice

## Editorial scope

Document a specific family or community storytelling practice with consent, context, and care about whose account is represented.

Example story question: How does an everyday telling keep one narrative meaningful?
