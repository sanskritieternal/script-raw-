# 004_sanatan_hindu_mythology_power_humility: Sanatan / Hindu Mythology — Authority Tested by Humility

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Authority Tested by Humility

## Editorial scope

Analyze a narrative in which power, status, or pride is challenged and identify the precise turning point.

Example story question: What does one story suggest about the use of power?
