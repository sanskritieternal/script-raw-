# 004_sanatan_hindu_mythology_boons_curses: Sanatan / Hindu Mythology — Boon, Curse, and Consequence

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Boon, Curse, and Consequence

## Editorial scope

Analyze the conditions and consequences of one boon or curse in its source context, rather than treating it as a generic magical device.

Example story question: How does one boon or curse redirect the plot?
