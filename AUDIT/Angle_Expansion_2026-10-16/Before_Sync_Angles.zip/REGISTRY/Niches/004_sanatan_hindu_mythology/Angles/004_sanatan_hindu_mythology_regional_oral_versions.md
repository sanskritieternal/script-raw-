# 004_sanatan_hindu_mythology_regional_oral_versions: Sanatan / Hindu Mythology — A Regional Story in Its Own Voice

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Regional Story in Its Own Voice

## Editorial scope

Document one regional oral telling with its language, performers, and community context rather than treating it as an incomplete Sanskrit version.

Example story question: What is distinctive about one regional telling of a sacred story?
