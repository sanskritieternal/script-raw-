# 004_sanatan_hindu_mythology_hanuman_story_cycles: Sanatan / Hindu Mythology — Hanuman Beyond a Single Episode

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Hanuman Beyond a Single Episode

## Editorial scope

Trace one Hanuman episode across specified tellings and examine changes in role, action, or devotional emphasis.

Example story question: How does one telling frame Hanuman's action differently?
