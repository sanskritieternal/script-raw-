# 004_sanatan_hindu_mythology_technology_innovation: Sanatan / Hindu Mythology — New Media and the Retelling of Sacred Stories

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** New Media and the Retelling of Sacred Stories

## Editorial scope

Study how a specific recording, broadcast, archive, or digital format changes access to a narrative and choices in its presentation.

Example story question: How did a new medium change the way one sacred story is told?
