# 004_sanatan_hindu_mythology_story_chronology: Sanatan / Hindu Mythology — Time Inside a Story and Time of Its Sources

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Time Inside a Story and Time of Its Sources

## Editorial scope

Separate narrative sequence, cosmological time, composition, and surviving evidence for one episode.

Example story question: What kind of time is a story describing, and what can be dated?
