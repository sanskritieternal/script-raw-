# 004_sanatan_hindu_mythology_mahabharata_retellings: Sanatan / Hindu Mythology — Mahabharata Episodes Across Traditions

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Mahabharata Episodes Across Traditions

## Editorial scope

Compare one named Mahabharata episode across textual or performance traditions and explain the narrative stakes of the variation.

Example story question: What does a variant Mahabharata episode emphasize differently?
