# 004_sanatan_hindu_mythology_war_peace_ethics: Sanatan / Hindu Mythology — War, Restraint, and Moral Argument

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** War, Restraint, and Moral Argument

## Editorial scope

Examine one conflict episode and the competing ethical claims in its source and commentary, without extracting a simple universal rule.

Example story question: How does this episode argue about the limits of warfare?
