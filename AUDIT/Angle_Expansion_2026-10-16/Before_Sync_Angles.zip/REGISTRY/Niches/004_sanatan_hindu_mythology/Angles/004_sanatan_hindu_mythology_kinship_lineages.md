# 004_sanatan_hindu_mythology_kinship_lineages: Sanatan / Hindu Mythology — Family Ties That Drive a Plot

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Family Ties That Drive a Plot

## Editorial scope

Map only the relationships necessary to understand a specified conflict, alliance, or succession in one narrative.

Example story question: How do family obligations shape the choices in one episode?
