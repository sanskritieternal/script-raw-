# 004_sanatan_hindu_mythology_ramayana_retellings: Sanatan / Hindu Mythology — Ramayana Episodes Across Traditions

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Ramayana Episodes Across Traditions

## Editorial scope

Compare one named Ramayana episode in two identified traditions, noting differences without ranking them by authenticity.

Example story question: How does one Ramayana episode change across named traditions?
