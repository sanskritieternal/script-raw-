# 004_sanatan_hindu_mythology_cross_community_retellings: Sanatan / Hindu Mythology — A Shared Story Across Communities

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Shared Story Across Communities

## Editorial scope

Compare how two named communities tell a related story and explain the different values or contexts each foregrounds.

Example story question: How do two communities give a shared story different meanings?
