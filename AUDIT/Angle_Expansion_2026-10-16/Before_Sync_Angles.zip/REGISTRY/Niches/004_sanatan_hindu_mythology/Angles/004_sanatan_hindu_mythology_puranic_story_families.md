# 004_sanatan_hindu_mythology_puranic_story_families: Sanatan / Hindu Mythology — One Puranic Story Family Across Texts

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** One Puranic Story Family Across Texts

## Editorial scope

Map recurring characters or events in two named Puranic accounts, with source-specific attribution.

Example story question: How do two Puranic accounts shape the same story differently?
