# 004_sanatan_hindu_mythology_performance_retellings: Sanatan / Hindu Mythology — A Story Reworked in Performance

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Story Reworked in Performance

## Editorial scope

Examine how a documented dance, theatre, recitation, or song adapts one episode through voice, gesture, and audience.

Example story question: What changes when a sacred episode is performed?
