# 004_sanatan_hindu_mythology_beginner_explainers: Sanatan / Hindu Mythology — A Reader's Guide to Hindu Sacred Narrative

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Reader's Guide to Hindu Sacred Narrative

## Editorial scope

Introduce an epic or Puranic story family, its main characters, source type, and diversity of tellings for a newcomer.

Example story question: How can a new reader approach a Hindu sacred story responsibly?
