# 004_sanatan_hindu_mythology_hidden_stories: Sanatan / Hindu Mythology — Lesser-Known Episodes with Clear Sources

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Lesser-Known Episodes with Clear Sources

## Editorial scope

Recover a less familiar narrative from a named source and explain why its context matters, without presenting it as a suppressed secret.

Example story question: What does a lesser-known episode add to a larger narrative?
