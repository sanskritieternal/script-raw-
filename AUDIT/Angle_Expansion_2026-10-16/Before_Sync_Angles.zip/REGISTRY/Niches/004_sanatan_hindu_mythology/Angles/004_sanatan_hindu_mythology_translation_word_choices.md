# 004_sanatan_hindu_mythology_translation_word_choices: Sanatan / Hindu Mythology — When Translation Changes a Story

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** When Translation Changes a Story

## Editorial scope

Choose one important term or passage and compare two identified translations with the source language where feasible.

Example story question: How do translation choices change the meaning of one episode?
