# 004_sanatan_hindu_mythology_source_attribution: Sanatan / Hindu Mythology — Where a Popular Story Is Actually Found

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Where a Popular Story Is Actually Found

## Editorial scope

Trace a circulating story to named textual, oral, or modern sources; state clearly when an attribution cannot be confirmed.

Example story question: Which source first supports a popular attribution for this story?
