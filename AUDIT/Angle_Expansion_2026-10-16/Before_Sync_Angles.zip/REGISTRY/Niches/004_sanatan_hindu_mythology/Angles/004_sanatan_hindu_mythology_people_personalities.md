# 004_sanatan_hindu_mythology_people_personalities: Sanatan / Hindu Mythology — A Character Through Different Tellings

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Character Through Different Tellings

## Editorial scope

Follow one narrative figure through two sourced versions, separating the character's literary role from claims about historical biography.

Example story question: How does a character's portrayal change across tellings?
