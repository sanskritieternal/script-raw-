# 004_sanatan_hindu_mythology_symbols_objects: Sanatan / Hindu Mythology — A Narrative Object and Its Meanings

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Narrative Object and Its Meanings

## Editorial scope

Trace one weapon, vehicle, garment, or other object through a named episode and distinguish source description from later iconography.

Example story question: How does one object change the choices in a narrative?
