# 004_sanatan_hindu_mythology_rise_fall: Sanatan / Hindu Mythology — Cycles of Power in Sacred Narratives

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Cycles of Power in Sacred Narratives

## Editorial scope

Trace a rise, crisis, and reversal within a named narrative; treat its moral pattern as an interpretation rather than a historical law.

Example story question: How does one story explain the rise and decline of power?
