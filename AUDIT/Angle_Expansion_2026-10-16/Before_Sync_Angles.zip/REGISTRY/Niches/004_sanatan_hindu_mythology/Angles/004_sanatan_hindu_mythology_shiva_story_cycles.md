# 004_sanatan_hindu_mythology_shiva_story_cycles: Sanatan / Hindu Mythology — A Shiva Narrative in Context

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Shiva Narrative in Context

## Editorial scope

Examine one Shiva-centered story across named sources or performances, keeping the episode central rather than attempting a full account of Shaivism.

Example story question: How does one Shiva narrative portray a particular relationship or value?
