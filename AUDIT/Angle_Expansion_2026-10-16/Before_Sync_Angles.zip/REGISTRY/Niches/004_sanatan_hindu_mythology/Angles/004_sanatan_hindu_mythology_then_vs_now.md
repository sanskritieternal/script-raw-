# 004_sanatan_hindu_mythology_then_vs_now: Sanatan / Hindu Mythology — A Story Across Generations

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Story Across Generations

## Editorial scope

Compare a specified older telling with a documented recent retelling, including what each audience and medium may have shaped.

Example story question: What changed when a sacred story was retold for a new audience?
