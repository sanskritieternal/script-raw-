# 004_sanatan_hindu_mythology_major_events: Sanatan / Hindu Mythology — An Epic Turning Point and Its Consequences

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** An Epic Turning Point and Its Consequences

## Editorial scope

Focus on one consequential event within a named epic and trace the choices, relationships, and later events it sets in motion.

Example story question: Why does one turning point matter to the rest of an epic?
