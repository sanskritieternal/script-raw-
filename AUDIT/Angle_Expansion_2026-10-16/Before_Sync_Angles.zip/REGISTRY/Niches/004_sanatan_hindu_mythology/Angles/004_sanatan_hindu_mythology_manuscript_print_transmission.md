# 004_sanatan_hindu_mythology_manuscript_print_transmission: Sanatan / Hindu Mythology — From Manuscript to Printed Story

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** From Manuscript to Printed Story

## Editorial scope

Trace a named narrative through a documented manuscript, edition, or publishing history and mark where editorial choices enter.

Example story question: How did copying or printing shape the version readers now know?
