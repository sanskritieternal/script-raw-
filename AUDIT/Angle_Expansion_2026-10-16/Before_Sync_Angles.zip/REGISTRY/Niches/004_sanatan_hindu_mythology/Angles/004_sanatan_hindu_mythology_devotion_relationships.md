# 004_sanatan_hindu_mythology_devotion_relationships: Sanatan / Hindu Mythology — Devotion Shown Through a Story

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Devotion Shown Through a Story

## Editorial scope

Examine a relationship of devotion in a specific narrative, distinguishing the story from a general survey of a devotional school.

Example story question: How is devotion expressed through action in this episode?
