# 004_sanatan_hindu_mythology_asura_perspectives: Sanatan / Hindu Mythology — Opponents as More Than Plot Devices

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Opponents as More Than Plot Devices

## Editorial scope

Compare portrayals of a named asura or antagonist across sourced tellings, avoiding a single moral label for all traditions.

Example story question: How do tellings differ in their portrayal of one antagonist?
