# 004_sanatan_hindu_mythology_vishnu_avatar_stories: Sanatan / Hindu Mythology — An Avatar Story Across Sources

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** An Avatar Story Across Sources

## Editorial scope

Compare one Vishnu avatar episode in named sources and identify what each telling emphasizes.

Example story question: How do two sources explain the purpose of one avatar episode?
