# 004_sanatan_hindu_mythology_exile_return: Sanatan / Hindu Mythology — What Exile Changes

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** What Exile Changes

## Editorial scope

Follow a named exile or return through relationships, authority, identity, and the story's resolution.

Example story question: How does exile transform a character's obligations?
