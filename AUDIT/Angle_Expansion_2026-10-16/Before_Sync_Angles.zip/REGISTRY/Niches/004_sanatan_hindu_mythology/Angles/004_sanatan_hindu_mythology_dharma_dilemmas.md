# 004_sanatan_hindu_mythology_dharma_dilemmas: Sanatan / Hindu Mythology — A Duty with No Easy Choice

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Duty with No Easy Choice

## Editorial scope

Examine competing obligations in one sourced episode and show how named interpreters or tellings assess the choice.

Example story question: Why is the right action contested in this episode?
