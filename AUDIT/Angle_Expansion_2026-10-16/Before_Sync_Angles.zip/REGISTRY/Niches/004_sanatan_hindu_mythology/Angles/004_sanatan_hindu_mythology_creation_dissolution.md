# 004_sanatan_hindu_mythology_creation_dissolution: Sanatan / Hindu Mythology — Creation and Dissolution as Narrative

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Creation and Dissolution as Narrative

## Editorial scope

Compare one sourced account of emergence or dissolution with another, noting theological and genre differences.

Example story question: How do two narratives describe the beginning or ending of a world?
