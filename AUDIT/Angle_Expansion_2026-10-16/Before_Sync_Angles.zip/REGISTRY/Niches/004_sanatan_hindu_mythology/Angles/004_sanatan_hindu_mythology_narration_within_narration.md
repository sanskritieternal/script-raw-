# 004_sanatan_hindu_mythology_narration_within_narration: Sanatan / Hindu Mythology — Who Tells the Story Inside the Story

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Who Tells the Story Inside the Story

## Editorial scope

Examine a frame narrative and how its speaker, listeners, and nested accounts shape the episode.

Example story question: Why does it matter who narrates a sacred episode?
