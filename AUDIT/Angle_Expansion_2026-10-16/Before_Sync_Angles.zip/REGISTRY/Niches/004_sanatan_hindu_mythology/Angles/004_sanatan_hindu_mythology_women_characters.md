# 004_sanatan_hindu_mythology_women_characters: Sanatan / Hindu Mythology — Women as Decision Makers in Sacred Stories

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Women as Decision Makers in Sacred Stories

## Editorial scope

Study a named woman's actions and voice in two sourced tellings, including differences in later interpretation.

Example story question: How does one woman's agency appear differently across versions?
