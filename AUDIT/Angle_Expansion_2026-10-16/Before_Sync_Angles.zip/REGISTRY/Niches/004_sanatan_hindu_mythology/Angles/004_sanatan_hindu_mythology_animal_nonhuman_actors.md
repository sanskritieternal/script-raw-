# 004_sanatan_hindu_mythology_animal_nonhuman_actors: Sanatan / Hindu Mythology — Nonhuman Figures with Narrative Agency

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Nonhuman Figures with Narrative Agency

## Editorial scope

Analyze the role of a named animal or nonhuman figure within a sourced episode, avoiding claims that all symbols have one fixed meaning.

Example story question: What changes when a nonhuman character acts in this story?
