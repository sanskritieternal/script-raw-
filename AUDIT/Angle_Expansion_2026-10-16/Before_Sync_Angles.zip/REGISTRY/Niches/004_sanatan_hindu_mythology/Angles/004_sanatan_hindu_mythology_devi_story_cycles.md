# 004_sanatan_hindu_mythology_devi_story_cycles: Sanatan / Hindu Mythology — A Goddess Narrative Across Tellings

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Goddess Narrative Across Tellings

## Editorial scope

Follow one Devi-centered episode with attention to its source, regional practice, and the agency of its figures.

Example story question: How do different tellings portray the goddess in one episode?
