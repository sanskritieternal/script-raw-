# 004_sanatan_hindu_mythology_vows_promises: Sanatan / Hindu Mythology — The Cost of a Vow

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** The Cost of a Vow

## Editorial scope

Trace a specific vow from the moment it is made through its intended and unintended consequences in a named telling.

Example story question: What does a character's promise cost later in the story?
