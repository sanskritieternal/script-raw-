# 004_sanatan_hindu_mythology_contested_interpretations: Sanatan / Hindu Mythology — When Communities Disagree About a Story

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** When Communities Disagree About a Story

## Editorial scope

Present two named interpretations of one episode fairly, identify their sources, and avoid treating disagreement as a sensational mystery.

Example story question: Why do communities read the same episode differently?
