# 004_sanatan_hindu_mythology_digital_adaptations: Sanatan / Hindu Mythology — Sacred Narrative in Digital Formats

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Sacred Narrative in Digital Formats

## Editorial scope

Study a specific game, animation, social post, or interactive adaptation and the narrative choices its format encourages.

Example story question: How does a digital format reshape one sacred episode?
