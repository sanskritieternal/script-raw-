# 004_sanatan_hindu_mythology_advanced_concepts: Sanatan / Hindu Mythology — Layers of Meaning in One Narrative

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Layers of Meaning in One Narrative

## Editorial scope

Compare literal plot, theological reading, moral interpretation, and performance context for one sourced episode.

Example story question: How can the same narrative support different interpretations?
