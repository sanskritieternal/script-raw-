# 004_sanatan_hindu_mythology_documentary_stories: Sanatan / Hindu Mythology — The Journey of One Living Retelling

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** The Journey of One Living Retelling

## Editorial scope

Follow one documented performance, publication, or community telling from source and creator choices to audience reception.

Example story question: How did one community bring a sacred story to a new audience?
