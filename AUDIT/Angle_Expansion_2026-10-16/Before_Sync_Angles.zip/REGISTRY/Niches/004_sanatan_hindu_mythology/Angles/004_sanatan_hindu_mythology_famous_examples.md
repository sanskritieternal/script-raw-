# 004_sanatan_hindu_mythology_famous_examples: Sanatan / Hindu Mythology — A Familiar Episode Across Its Sources

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Familiar Episode Across Its Sources

## Editorial scope

Take one widely known episode and compare what two identified tellings include, omit, or emphasize.

Example story question: How does one famous episode change between two tellings?
