# 004_sanatan_hindu_mythology_rivers_mountains: Sanatan / Hindu Mythology — Rivers and Mountains in Story Worlds

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Rivers and Mountains in Story Worlds

## Editorial scope

Analyze a named river or mountain in a specific narrative and compare its symbolic and geographic roles where supported.

Example story question: How does a river or mountain drive the events of this story?
