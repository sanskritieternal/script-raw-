# 004_sanatan_hindu_mythology_krishna_story_cycles: Sanatan / Hindu Mythology — One Krishna Story Beyond the Summary

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** One Krishna Story Beyond the Summary

## Editorial scope

Study a specified Krishna episode across identified texts or performances, distinguishing childhood, epic, and devotional settings.

Example story question: How does one Krishna episode change with its narrative setting?
