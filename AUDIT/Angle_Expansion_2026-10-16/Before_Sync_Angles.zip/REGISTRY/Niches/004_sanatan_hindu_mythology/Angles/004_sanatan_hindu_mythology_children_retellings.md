# 004_sanatan_hindu_mythology_children_retellings: Sanatan / Hindu Mythology — Adapting a Sacred Story for Children

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Adapting a Sacred Story for Children

## Editorial scope

Compare a source episode with a named children's retelling and examine what complexity or ambiguity is preserved or removed.

Example story question: What changes when this sacred story is told to children?
