# 004_sanatan_hindu_mythology_fate_choice: Sanatan / Hindu Mythology — Prophecy, Fate, and Human Choice

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Prophecy, Fate, and Human Choice

## Editorial scope

Trace one prophecy or foretelling and the decisions characters make in response within a named source.

Example story question: Does a prophecy remove choice in this narrative?
