# 004_sanatan_hindu_mythology_festivals_story_context: Sanatan / Hindu Mythology — The Story Invoked by a Festival

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** The Story Invoked by a Festival

## Editorial scope

Identify which sourced narrative a specific celebration invokes and how local practice may emphasize different parts of it.

Example story question: Which episode is told through this festival's practice?
