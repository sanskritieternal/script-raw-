# 004_sanatan_hindu_mythology_hospitality_generosity: Sanatan / Hindu Mythology — Hospitality as a Plot Decision

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Hospitality as a Plot Decision

## Editorial scope

Examine one act of welcome, refusal, or giving and the consequences it sets in motion in a named source.

Example story question: Why does an act of hospitality matter to this plot?
