# 004_sanatan_hindu_mythology_temple_visual_narratives: Sanatan / Hindu Mythology — A Sacred Story Told in Images

> Subject category: Hindu_Traditions
> CAT: ../CAT_004_sanatan_hindu_mythology.md
> NICHE: ../NICHE_004_sanatan_hindu_mythology.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** A Sacred Story Told in Images

## Editorial scope

Read a specific sculptural or painted narrative sequence with its site, date evidence, and relevant textual comparisons.

Example story question: How does a temple image tell a story differently from a text?
