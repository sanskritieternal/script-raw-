# 029_dinosaurs_prehistoric_world_beginner_explainers: Dinosaurs & Prehistoric World — Beginner Explainers

> Subject category: Earth_Environment
> CAT: ../CAT_029_dinosaurs_prehistoric_world.md
> NICHE: ../NICHE_029_dinosaurs_prehistoric_world.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Beginner Explainers
