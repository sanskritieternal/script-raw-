# 027_genetics_evolution_people_personalities: Genetics & Evolution — People & Personalities

> Subject category: Life_Biology
> CAT: ../CAT_027_genetics_evolution.md
> NICHE: ../NICHE_027_genetics_evolution.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** People & Personalities
