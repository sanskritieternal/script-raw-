# 027_genetics_evolution_then_vs_now: Genetics & Evolution — Then vs Now

> Subject category: Life_Biology
> CAT: ../CAT_027_genetics_evolution.md
> NICHE: ../NICHE_027_genetics_evolution.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Then vs Now
