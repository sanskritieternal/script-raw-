# 027_genetics_evolution_rise_fall: Genetics & Evolution — Rise & Fall

> Subject category: Life_Biology
> CAT: ../CAT_027_genetics_evolution.md
> NICHE: ../NICHE_027_genetics_evolution.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Rise & Fall
