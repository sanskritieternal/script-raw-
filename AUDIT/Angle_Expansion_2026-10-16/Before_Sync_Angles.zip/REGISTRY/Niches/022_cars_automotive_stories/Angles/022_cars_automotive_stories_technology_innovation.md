# 022_cars_automotive_stories_technology_innovation: Cars / Automotive Stories — Technology & Innovation

> Subject category: Transport_Engineering
> CAT: ../CAT_022_cars_automotive_stories.md
> NICHE: ../NICHE_022_cars_automotive_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Technology & Innovation
