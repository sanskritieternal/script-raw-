# 022_cars_automotive_stories_documentary_stories: Cars / Automotive Stories — Documentary Stories

> Subject category: Transport_Engineering
> CAT: ../CAT_022_cars_automotive_stories.md
> NICHE: ../NICHE_022_cars_automotive_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Documentary Stories
