# 022_cars_automotive_stories_advanced_concepts: Cars / Automotive Stories — Advanced Concepts

> Subject category: Transport_Engineering
> CAT: ../CAT_022_cars_automotive_stories.md
> NICHE: ../NICHE_022_cars_automotive_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Advanced Concepts
