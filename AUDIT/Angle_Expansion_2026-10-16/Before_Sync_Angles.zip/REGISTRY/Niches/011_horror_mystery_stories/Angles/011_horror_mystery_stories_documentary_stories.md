# 011_horror_mystery_stories_documentary_stories: Horror / Mystery Stories — Documentary Stories

> Subject category: Speculative_Stories
> CAT: ../CAT_011_horror_mystery_stories.md
> NICHE: ../NICHE_011_horror_mystery_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Documentary Stories
