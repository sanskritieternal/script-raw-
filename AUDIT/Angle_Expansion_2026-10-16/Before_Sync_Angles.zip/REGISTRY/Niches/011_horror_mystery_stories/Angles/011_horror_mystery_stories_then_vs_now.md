# 011_horror_mystery_stories_then_vs_now: Horror / Mystery Stories — Then vs Now

> Subject category: Speculative_Stories
> CAT: ../CAT_011_horror_mystery_stories.md
> NICHE: ../NICHE_011_horror_mystery_stories.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Then vs Now
