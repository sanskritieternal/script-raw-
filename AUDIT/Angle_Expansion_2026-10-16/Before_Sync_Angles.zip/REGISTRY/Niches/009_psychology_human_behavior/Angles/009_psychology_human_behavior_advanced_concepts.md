# 009_psychology_human_behavior_advanced_concepts: Psychology / Human Behavior — Advanced Concepts

> Subject category: People_Communities
> CAT: ../CAT_009_psychology_human_behavior.md
> NICHE: ../NICHE_009_psychology_human_behavior.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Advanced Concepts
