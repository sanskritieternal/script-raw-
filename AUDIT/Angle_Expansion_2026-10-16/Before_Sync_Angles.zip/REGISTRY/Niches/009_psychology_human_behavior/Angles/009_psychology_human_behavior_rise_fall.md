# 009_psychology_human_behavior_rise_fall: Psychology / Human Behavior — Rise & Fall

> Subject category: People_Communities
> CAT: ../CAT_009_psychology_human_behavior.md
> NICHE: ../NICHE_009_psychology_human_behavior.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Rise & Fall
