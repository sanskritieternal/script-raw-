# 028_ocean_deep_sea_documentary_stories: Ocean & Deep Sea — Documentary Stories

> Subject category: Earth_Environment
> CAT: ../CAT_028_ocean_deep_sea.md
> NICHE: ../NICHE_028_ocean_deep_sea.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Documentary Stories
