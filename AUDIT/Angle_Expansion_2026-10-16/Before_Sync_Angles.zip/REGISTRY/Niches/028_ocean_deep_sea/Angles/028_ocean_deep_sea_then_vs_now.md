# 028_ocean_deep_sea_then_vs_now: Ocean & Deep Sea — Then vs Now

> Subject category: Earth_Environment
> CAT: ../CAT_028_ocean_deep_sea.md
> NICHE: ../NICHE_028_ocean_deep_sea.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Then vs Now
