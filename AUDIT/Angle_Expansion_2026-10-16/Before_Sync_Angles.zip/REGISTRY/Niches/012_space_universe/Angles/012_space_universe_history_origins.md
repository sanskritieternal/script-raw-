# 012_space_universe_history_origins: Space / Universe — History & Origins

> Subject category: Space_Astronomy
> CAT: ../CAT_012_space_universe.md
> NICHE: ../NICHE_012_space_universe.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** History & Origins
