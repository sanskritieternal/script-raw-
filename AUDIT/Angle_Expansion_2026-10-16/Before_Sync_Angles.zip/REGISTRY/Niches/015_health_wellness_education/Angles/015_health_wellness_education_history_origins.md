# 015_health_wellness_education_history_origins: Health & Wellness Education — History & Origins

> Subject category: Medicine_Healthcare
> CAT: ../CAT_015_health_wellness_education.md
> NICHE: ../NICHE_015_health_wellness_education.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** History & Origins
