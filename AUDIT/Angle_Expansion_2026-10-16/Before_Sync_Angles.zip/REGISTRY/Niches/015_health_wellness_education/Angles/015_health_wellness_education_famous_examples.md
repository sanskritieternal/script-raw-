# 015_health_wellness_education_famous_examples: Health & Wellness Education — Famous Examples

> Subject category: Medicine_Healthcare
> CAT: ../CAT_015_health_wellness_education.md
> NICHE: ../NICHE_015_health_wellness_education.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Famous Examples
