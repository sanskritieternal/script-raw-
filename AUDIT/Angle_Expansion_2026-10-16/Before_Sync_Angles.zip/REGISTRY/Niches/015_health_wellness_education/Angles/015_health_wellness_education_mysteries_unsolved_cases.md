# 015_health_wellness_education_mysteries_unsolved_cases: Health & Wellness Education — Mysteries & Unsolved Cases

> Subject category: Medicine_Healthcare
> CAT: ../CAT_015_health_wellness_education.md
> NICHE: ../NICHE_015_health_wellness_education.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Mysteries & Unsolved Cases
