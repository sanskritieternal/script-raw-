# 021_luxury_rich_lifestyle_people_personalities: Luxury / Rich Lifestyle — People & Personalities

> Subject category: Commerce_Industry
> CAT: ../CAT_021_luxury_rich_lifestyle.md
> NICHE: ../NICHE_021_luxury_rich_lifestyle.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** People & Personalities
