# 005_documentary_storytelling_how_it_works: Documentary Storytelling — How It Works

> Subject category: Film_Production
> CAT: ../CAT_005_documentary_storytelling.md
> NICHE: ../NICHE_005_documentary_storytelling.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
