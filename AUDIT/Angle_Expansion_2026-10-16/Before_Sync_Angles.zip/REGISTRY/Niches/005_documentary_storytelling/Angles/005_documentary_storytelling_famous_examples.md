# 005_documentary_storytelling_famous_examples: Documentary Storytelling — Famous Examples

> Subject category: Film_Production
> CAT: ../CAT_005_documentary_storytelling.md
> NICHE: ../NICHE_005_documentary_storytelling.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Famous Examples
