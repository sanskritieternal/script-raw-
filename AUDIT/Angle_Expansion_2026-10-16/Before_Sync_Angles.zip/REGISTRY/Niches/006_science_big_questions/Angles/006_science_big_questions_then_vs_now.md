# 006_science_big_questions_then_vs_now: Science & Big Questions — Then vs Now

> Subject category: Physical_Sciences
> CAT: ../CAT_006_science_big_questions.md
> NICHE: ../NICHE_006_science_big_questions.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Then vs Now
