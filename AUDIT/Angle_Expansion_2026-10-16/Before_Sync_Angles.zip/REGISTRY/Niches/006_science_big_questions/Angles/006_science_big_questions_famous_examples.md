# 006_science_big_questions_famous_examples: Science & Big Questions — Famous Examples

> Subject category: Physical_Sciences
> CAT: ../CAT_006_science_big_questions.md
> NICHE: ../NICHE_006_science_big_questions.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Famous Examples
