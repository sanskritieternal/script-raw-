# 025_gaming_stories_lore_how_it_works: Gaming Stories / Lore — How It Works

> Subject category: Games_Puzzles
> CAT: ../CAT_025_gaming_stories_lore.md
> NICHE: ../NICHE_025_gaming_stories_lore.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
