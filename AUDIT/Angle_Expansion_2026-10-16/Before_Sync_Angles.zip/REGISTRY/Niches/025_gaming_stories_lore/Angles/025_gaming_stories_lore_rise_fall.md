# 025_gaming_stories_lore_rise_fall: Gaming Stories / Lore — Rise & Fall

> Subject category: Games_Puzzles
> CAT: ../CAT_025_gaming_stories_lore.md
> NICHE: ../NICHE_025_gaming_stories_lore.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Rise & Fall
