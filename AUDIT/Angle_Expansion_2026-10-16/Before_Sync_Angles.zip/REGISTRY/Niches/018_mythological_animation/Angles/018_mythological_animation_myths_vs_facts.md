# 018_mythological_animation_myths_vs_facts: Mythological Animation — Myths vs Facts

> Subject category: Fiction_Worldbuilding
> CAT: ../CAT_018_mythological_animation.md
> NICHE: ../NICHE_018_mythological_animation.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Myths vs Facts
