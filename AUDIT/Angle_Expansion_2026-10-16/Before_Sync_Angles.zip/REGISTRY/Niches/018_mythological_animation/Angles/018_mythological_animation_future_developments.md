# 018_mythological_animation_future_developments: Mythological Animation — Future Developments

> Subject category: Fiction_Worldbuilding
> CAT: ../CAT_018_mythological_animation.md
> NICHE: ../NICHE_018_mythological_animation.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** Future Developments
