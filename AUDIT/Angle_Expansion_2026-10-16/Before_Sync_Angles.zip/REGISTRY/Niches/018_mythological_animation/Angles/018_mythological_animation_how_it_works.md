# 018_mythological_animation_how_it_works: Mythological Animation — How It Works

> Subject category: Fiction_Worldbuilding
> CAT: ../CAT_018_mythological_animation.md
> NICHE: ../NICHE_018_mythological_animation.md

This angle supplies Q3 only. All other defaults come from the niche CAT file.

## Q3: Primary Story Angle
**Default:** How It Works
