# 281 Ayurveda: Subject Coverage and Episode Proposals

Updated: 2026-10-22 · **Initial subject map; proposed, not researched**

**3 subject categories · 12 topic proposals.**

A starting subject map for a Ayurveda YouTube channel. Categories organize concrete subtopics; each entry supplies an episode question, a research outline and a boundary for case selection. Counts follow the authored coverage, with no imposed topic maximum.

[All-niche index](../ALL_NICHE_TOPIC_BANKS.md) · [Editable JSON](./IN_DEPTH_TOPIC_BANK.json) · [Expansion method](../ALL_NICHE_EXPANSION_GUIDE.md)

This is a first coverage pass with concrete subject headings and research briefs. It has less editorial depth than the 120-question Meditation, Pranayama and Yoga pilots. It is not exhaustive, and has no fixed topic limit. The suggested research questions and outlines use domain-specific editorial patterns; they are proposals to refine against actual sources, not evidence that the research has been done.

The IDs refer to catalog entries, not episodes produced. Angles are deliberately unassigned until the actual niche angle scope and selected case are reviewed. No topic is ready_for_project or verified. The research outline is not a follow-along lesson, treatment plan, legal instruction, investment recommendation or hazardous procedure.

## Subject map

| Category | Research mode | Topic proposals |
|---|---|---:|
| CATALOG-281-01: Ayurvedic frameworks | tradition | 4 |
| CATALOG-281-02: Texts and institutions | history | 4 |
| CATALOG-281-03: Evidence and safeguards | health | 4 |

## Detailed proposals

### Ayurvedic frameworks

**Research standard:** Identify the text, edition, translator, commentary, community and ritual context as applicable. Attribute theological and spiritual claims, preserve regional variation and respect public versus restricted knowledge.

**Source types to locate:** primary texts in traceable editions; authorized public teaching and ritual descriptions; consented community accounts and critical historical studies. These source types are not topic-specific sources already inspected.

#### BANK-281-001 — Dosha concepts in classical texts

**Video question:** Dosha concepts in classical texts: how do named sources and interpreters explain it?

**Coverage boundary:** Primary context: Ayurveda; branch: Ayurvedic frameworks. Address Dosha concepts in classical texts through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Identify the source passages, images or authorized descriptions that define Dosha concepts in classical texts.
- Explain key terms within their own literary, philosophical or devotional setting.
- Compare a second attributed interpretation without merging distinct traditions or ranking spiritual truth.
- Document what is uncertain, restricted, disputed or lost in translation; choose visuals that do not invent sacred attributes.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-002 — Prakriti and vikriti distinctions

**Video question:** Prakriti and vikriti distinctions: how do named sources and interpreters explain it?

**Coverage boundary:** Primary context: Ayurveda; branch: Ayurvedic frameworks. Address Prakriti and vikriti distinctions through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Identify the source passages, images or authorized descriptions that define Prakriti and vikriti distinctions.
- Explain key terms within their own literary, philosophical or devotional setting.
- Compare a second attributed interpretation without merging distinct traditions or ranking spiritual truth.
- Document what is uncertain, restricted, disputed or lost in translation; choose visuals that do not invent sacred attributes.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-003 — Agni interpretations

**Video question:** Agni interpretations: how do named sources and interpreters explain it?

**Coverage boundary:** Primary context: Ayurveda; branch: Ayurvedic frameworks. Address Agni interpretations through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Identify the source passages, images or authorized descriptions that define Agni interpretations.
- Explain key terms within their own literary, philosophical or devotional setting.
- Compare a second attributed interpretation without merging distinct traditions or ranking spiritual truth.
- Document what is uncertain, restricted, disputed or lost in translation; choose visuals that do not invent sacred attributes.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-004 — Dinacharya in source context

**Video question:** Dinacharya in source context: how do named sources and interpreters explain it?

**Coverage boundary:** Primary context: Ayurveda; branch: Ayurvedic frameworks. Address Dinacharya in source context through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Identify the source passages, images or authorized descriptions that define Dinacharya in source context.
- Explain key terms within their own literary, philosophical or devotional setting.
- Compare a second attributed interpretation without merging distinct traditions or ranking spiritual truth.
- Document what is uncertain, restricted, disputed or lost in translation; choose visuals that do not invent sacred attributes.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Texts and institutions

**Research standard:** Compare dated primary records, material evidence and historical scholarship. Distinguish event dates, the dates of surviving witnesses, later retellings and disagreement. Do not invent quotations, intentions or an unbroken lineage.

**Source types to locate:** dated archival records and original publications; inscriptions, artifacts or photographs with provenance; critical editions and historical scholarship. These source types are not topic-specific sources already inspected.

#### BANK-281-005 — Charaka Samhita transmission

**Video question:** Charaka Samhita transmission: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Ayurveda; branch: Texts and institutions. Address Charaka Samhita transmission through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Charaka Samhita transmission in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-006 — Sushruta Samhita history

**Video question:** Sushruta Samhita history: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Ayurveda; branch: Texts and institutions. Address Sushruta Samhita history through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Sushruta Samhita history in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-007 — Ashtanga Hridaya organization

**Video question:** Ashtanga Hridaya organization: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Ayurveda; branch: Texts and institutions. Address Ashtanga Hridaya organization through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Ashtanga Hridaya organization in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-008 — Contemporary practitioner education

**Video question:** Contemporary practitioner education: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Ayurveda; branch: Texts and institutions. Address Contemporary practitioner education through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Contemporary practitioner education in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Evidence and safeguards

**Research standard:** Inspect current professional guidance and original studies for the exact population, intervention or measurement. Report comparators, absolute outcomes, uncertainty, harms and limits. Do not diagnose, prescribe or imply that education replaces professional care.

**Source types to locate:** current official clinical or public-health guidance; original trials, cohort studies or diagnostic-validation reports; study registrations, protocols and adverse-event records. These source types are not topic-specific sources already inspected.

#### BANK-281-009 — Clinical evaluation of specific preparations

**Video question:** Clinical evaluation of specific preparations: what does current evidence establish for a defined population?

**Coverage boundary:** Primary context: Ayurveda; branch: Evidence and safeguards. Address Clinical evaluation of specific preparations through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Clinical evaluation of specific preparations, the population and the outcome; distinguish normal variation, symptoms, screening and diagnosis where applicable.
- Explain the relevant mechanism without turning a plausible mechanism into proof of a clinical effect.
- Compare actual study designs, outcomes and follow-up; inspect harms, missing data and generalizability.
- State the evidence limits and the boundary between public education and an individual's clinical assessment.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-010 — Heavy-metal contamination testing

**Video question:** Heavy-metal contamination testing: what does current evidence establish for a defined population?

**Coverage boundary:** Primary context: Ayurveda; branch: Evidence and safeguards. Address Heavy-metal contamination testing through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Heavy-metal contamination testing, the population and the outcome; distinguish normal variation, symptoms, screening and diagnosis where applicable.
- Explain the relevant mechanism without turning a plausible mechanism into proof of a clinical effect.
- Compare actual study designs, outcomes and follow-up; inspect harms, missing data and generalizability.
- State the evidence limits and the boundary between public education and an individual's clinical assessment.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-011 — Herb-drug interaction evidence

**Video question:** Herb-drug interaction evidence: what does current evidence establish for a defined population?

**Coverage boundary:** Primary context: Ayurveda; branch: Evidence and safeguards. Address Herb-drug interaction evidence through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Herb-drug interaction evidence, the population and the outcome; distinguish normal variation, symptoms, screening and diagnosis where applicable.
- Explain the relevant mechanism without turning a plausible mechanism into proof of a clinical effect.
- Compare actual study designs, outcomes and follow-up; inspect harms, missing data and generalizability.
- State the evidence limits and the boundary between public education and an individual's clinical assessment.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-281-012 — Traditional use versus demonstrated efficacy

**Video question:** Traditional use versus demonstrated efficacy: what does current evidence establish for a defined population?

**Coverage boundary:** Primary context: Ayurveda; branch: Evidence and safeguards. Address Traditional use versus demonstrated efficacy through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Traditional use versus demonstrated efficacy, the population and the outcome; distinguish normal variation, symptoms, screening and diagnosis where applicable.
- Explain the relevant mechanism without turning a plausible mechanism into proof of a clinical effect.
- Compare actual study designs, outcomes and follow-up; inspect harms, missing data and generalizability.
- State the evidence limits and the boundary between public education and an individual's clinical assessment.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

## Relationship to neighboring niches

The following homes have deliberately related subject matter. They are navigation leads, not proof that the same question belongs in every bank. Choose one primary home for an actual episode and link it elsewhere. Where a subject appears in more than one context, retain the distinct case, population, system or interpretive question.

- [282 Buddhist Philosophy](../282_buddhist_philosophy/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [283 Judaism History](../283_judaism_history/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [284 Christianity History](../284_christianity_history/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [285 Islamic History](../285_islamic_history/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [286 Sikh History](../286_sikh_history/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [287 Jainism](../287_jainism/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.

## Production handoff

- Keep the BANK ID in notes. Refine the research question with an exact text edition, jurisdiction, population, product version, place, time range or clearly labeled fictional premise.
- Inspect actual sources; no source was verified by generating this map. Apply the existing registry planning and idea readiness process before project creation.
- Choose a current registered angle only after reading its niche-specific scope. This initial map has not checked or assigned angle plans for these entries.
- Keep Q1-Q42, CAT defaults, project snapshots, output locations and production gates unchanged. Catalog counts are not production or publication counts.
- Review neighboring banks for semantic overlap and follow the existing Phase 1 claim-ledger requirements. Add qualified review when required by the production contract.

## Open coverage

This initial map does not exhaust the niche, its regions, time periods, named case studies, texts, technical variants or disputed questions. It has not performed source-feasibility checks, semantic duplicate review of every pair, trend analysis, claim verification or episode production. Expand any category freely after identifying a real coverage gap; add categories where the subject requires them. Preserve existing IDs when refining wording and allocate new IDs only for genuinely new proposals.
