# 442 Materials Engineering: Subject Coverage and Episode Proposals

Updated: 2026-10-22 · **Initial subject map; proposed, not researched**

**3 subject categories · 9 topic proposals.**

A starting subject map for a Materials Engineering YouTube channel. Categories organize concrete subtopics; each entry supplies an episode question, a research outline and a boundary for case selection. Counts follow the authored coverage, with no imposed topic maximum.

[All-niche index](../ALL_NICHE_TOPIC_BANKS.md) · [Editable JSON](./IN_DEPTH_TOPIC_BANK.json) · [Expansion method](../ALL_NICHE_EXPANSION_GUIDE.md)

This is a first coverage pass with concrete subject headings and research briefs. It has less editorial depth than the 120-question Meditation, Pranayama and Yoga pilots. It is not exhaustive, and has no fixed topic limit. The suggested research questions and outlines use domain-specific editorial patterns; they are proposals to refine against actual sources, not evidence that the research has been done.

The IDs refer to catalog entries, not episodes produced. Angles are deliberately unassigned until the actual niche angle scope and selected case are reviewed. No topic is ready_for_project or verified. The research outline is not a follow-along lesson, treatment plan, legal instruction, investment recommendation or hazardous procedure.

## Subject map

| Category | Research mode | Topic proposals |
|---|---|---:|
| CATALOG-442-01: Material selection | technical | 3 |
| CATALOG-442-02: Processing | technical | 3 |
| CATALOG-442-03: Lifecycle | science | 3 |

## Detailed proposals

### Material selection

**Research standard:** Use the actual system documentation, a worked implementation and measurements. Identify inputs, outputs, constraints, tolerances, failure conditions and the limits of the example. Do not provide hazardous construction or unauthorized access procedures.

**Source types to locate:** original engineering papers; official versioned product or standards documentation; test reports and drawings with clear provenance. These source types are not topic-specific sources already inspected.

#### BANK-442-001 — Strength-to-weight design

**Video question:** Strength-to-weight design: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Materials Engineering; branch: Material selection. Address Strength-to-weight design through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Strength-to-weight design.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-442-002 — Creep resistance

**Video question:** Creep resistance: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Materials Engineering; branch: Material selection. Address Creep resistance through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Creep resistance.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-442-003 — Wear-resistant surfaces

**Video question:** Wear-resistant surfaces: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Materials Engineering; branch: Material selection. Address Wear-resistant surfaces through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Wear-resistant surfaces.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Processing

**Research standard:** Use the actual system documentation, a worked implementation and measurements. Identify inputs, outputs, constraints, tolerances, failure conditions and the limits of the example. Do not provide hazardous construction or unauthorized access procedures.

**Source types to locate:** original engineering papers; official versioned product or standards documentation; test reports and drawings with clear provenance. These source types are not topic-specific sources already inspected.

#### BANK-442-004 — Heat treatment

**Video question:** Heat treatment: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Materials Engineering; branch: Processing. Address Heat treatment through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Heat treatment.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-442-005 — Additive manufacturing microstructures

**Video question:** Additive manufacturing microstructures: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Materials Engineering; branch: Processing. Address Additive manufacturing microstructures through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Additive manufacturing microstructures.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-442-006 — Composite layup

**Video question:** Composite layup: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Materials Engineering; branch: Processing. Address Composite layup through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Composite layup.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Lifecycle

**Research standard:** Use original observations or experiments, an appropriate scientific reference and the actual measurement method. Distinguish mechanisms, correlations, model assumptions, uncertainty and limits of generalization.

**Source types to locate:** original research reports and data; research-institution observation records; methods papers and current scientific reference works. These source types are not topic-specific sources already inspected.

#### BANK-442-007 — Material recycling compatibility

**Video question:** Material recycling compatibility: what mechanisms and measurements support the explanation?

**Coverage boundary:** Primary context: Materials Engineering; branch: Lifecycle. Address Material recycling compatibility through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Material recycling compatibility precisely and identify the scale, system or population being studied.
- Explain the proposed mechanism with an observable example; distinguish model from direct observation.
- Inspect how the key quantity is measured and which controls or comparison conditions matter.
- Discuss uncertainty, alternative explanations and a result that would challenge the account.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-442-008 — Corrosion testing

**Video question:** Corrosion testing: what mechanisms and measurements support the explanation?

**Coverage boundary:** Primary context: Materials Engineering; branch: Lifecycle. Address Corrosion testing through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Corrosion testing precisely and identify the scale, system or population being studied.
- Explain the proposed mechanism with an observable example; distinguish model from direct observation.
- Inspect how the key quantity is measured and which controls or comparison conditions matter.
- Discuss uncertainty, alternative explanations and a result that would challenge the account.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-442-009 — Failure analysis

**Video question:** Failure analysis: what mechanisms and measurements support the explanation?

**Coverage boundary:** Primary context: Materials Engineering; branch: Lifecycle. Address Failure analysis through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Failure analysis precisely and identify the scale, system or population being studied.
- Explain the proposed mechanism with an observable example; distinguish model from direct observation.
- Inspect how the key quantity is measured and which controls or comparison conditions matter.
- Discuss uncertainty, alternative explanations and a result that would challenge the account.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

## Relationship to neighboring niches

The following homes have deliberately related subject matter. They are navigation leads, not proof that the same question belongs in every bank. Choose one primary home for an actual episode and link it elsewhere. Where a subject appears in more than one context, retain the distinct case, population, system or interpretive question.

- [113 Energy & Power](../113_energy_power/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [114 Water](../114_water/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [157 Materials Science](../157_materials_science/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [158 Batteries & Energy Storage](../158_batteries_energy_storage/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [160 Data Centers & Infrastructure](../160_data_centers_infrastructure/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [161 Electricity & Electronics](../161_electricity_electronics/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.

## Production handoff

- Keep the BANK ID in notes. Refine the research question with an exact text edition, jurisdiction, population, product version, place, time range or clearly labeled fictional premise.
- Inspect actual sources; no source was verified by generating this map. Apply the existing registry planning and idea readiness process before project creation.
- Choose a current registered angle only after reading its niche-specific scope. This initial map has not checked or assigned angle plans for these entries.
- Keep Q1-Q42, CAT defaults, project snapshots, output locations and production gates unchanged. Catalog counts are not production or publication counts.
- Review neighboring banks for semantic overlap and follow the existing Phase 1 claim-ledger requirements. Add qualified review when required by the production contract.

## Open coverage

This initial map does not exhaust the niche, its regions, time periods, named case studies, texts, technical variants or disputed questions. It has not performed source-feasibility checks, semantic duplicate review of every pair, trend analysis, claim verification or episode production. Expand any category freely after identifying a real coverage gap; add categories where the subject requires them. Preserve existing IDs when refining wording and allocate new IDs only for genuinely new proposals.
