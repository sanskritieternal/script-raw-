# 434 Gem Mining: Subject Coverage and Episode Proposals

Updated: 2026-10-22 · **Initial subject map; proposed, not researched**

**3 subject categories · 9 topic proposals.**

A starting subject map for a Gem Mining YouTube channel. Categories organize concrete subtopics; each entry supplies an episode question, a research outline and a boundary for case selection. Counts follow the authored coverage, with no imposed topic maximum.

[All-niche index](../ALL_NICHE_TOPIC_BANKS.md) · [Editable JSON](./IN_DEPTH_TOPIC_BANK.json) · [Expansion method](../ALL_NICHE_EXPANSION_GUIDE.md)

This is a first coverage pass with concrete subject headings and research briefs. It has less editorial depth than the 120-question Meditation, Pranayama and Yoga pilots. It is not exhaustive, and has no fixed topic limit. The suggested research questions and outlines use domain-specific editorial patterns; they are proposals to refine against actual sources, not evidence that the research has been done.

The IDs refer to catalog entries, not episodes produced. Angles are deliberately unassigned until the actual niche angle scope and selected case are reviewed. No topic is ready_for_project or verified. The research outline is not a follow-along lesson, treatment plan, legal instruction, investment recommendation or hazardous procedure.

## Subject map

| Category | Research mode | Topic proposals |
|---|---|---:|
| CATALOG-434-01: Gem deposits | science | 3 |
| CATALOG-434-02: Extraction | technical | 3 |
| CATALOG-434-03: Trade accountability | civic | 3 |

## Detailed proposals

### Gem deposits

**Research standard:** Use original observations or experiments, an appropriate scientific reference and the actual measurement method. Distinguish mechanisms, correlations, model assumptions, uncertainty and limits of generalization.

**Source types to locate:** original research reports and data; research-institution observation records; methods papers and current scientific reference works. These source types are not topic-specific sources already inspected.

#### BANK-434-001 — Alluvial gemstone concentration

**Video question:** Alluvial gemstone concentration: what mechanisms and measurements support the explanation?

**Coverage boundary:** Primary context: Gem Mining; branch: Gem deposits. Address Alluvial gemstone concentration through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Alluvial gemstone concentration precisely and identify the scale, system or population being studied.
- Explain the proposed mechanism with an observable example; distinguish model from direct observation.
- Inspect how the key quantity is measured and which controls or comparison conditions matter.
- Discuss uncertainty, alternative explanations and a result that would challenge the account.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-434-002 — Pegmatite-hosted gems

**Video question:** Pegmatite-hosted gems: what mechanisms and measurements support the explanation?

**Coverage boundary:** Primary context: Gem Mining; branch: Gem deposits. Address Pegmatite-hosted gems through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Pegmatite-hosted gems precisely and identify the scale, system or population being studied.
- Explain the proposed mechanism with an observable example; distinguish model from direct observation.
- Inspect how the key quantity is measured and which controls or comparison conditions matter.
- Discuss uncertainty, alternative explanations and a result that would challenge the account.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-434-003 — Kimberlite exploration

**Video question:** Kimberlite exploration: what mechanisms and measurements support the explanation?

**Coverage boundary:** Primary context: Gem Mining; branch: Gem deposits. Address Kimberlite exploration through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Define Kimberlite exploration precisely and identify the scale, system or population being studied.
- Explain the proposed mechanism with an observable example; distinguish model from direct observation.
- Inspect how the key quantity is measured and which controls or comparison conditions matter.
- Discuss uncertainty, alternative explanations and a result that would challenge the account.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Extraction

**Research standard:** Use the actual system documentation, a worked implementation and measurements. Identify inputs, outputs, constraints, tolerances, failure conditions and the limits of the example. Do not provide hazardous construction or unauthorized access procedures.

**Source types to locate:** original engineering papers; official versioned product or standards documentation; test reports and drawings with clear provenance. These source types are not topic-specific sources already inspected.

#### BANK-434-004 — Artisanal sorting

**Video question:** Artisanal sorting: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Gem Mining; branch: Extraction. Address Artisanal sorting through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Artisanal sorting.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-434-005 — Recovery versus damage

**Video question:** Recovery versus damage: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Gem Mining; branch: Extraction. Address Recovery versus damage through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Recovery versus damage.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-434-006 — Water use at gem sites

**Video question:** Water use at gem sites: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Gem Mining; branch: Extraction. Address Water use at gem sites through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Water use at gem sites.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Trade accountability

**Research standard:** Use the current official legal text, policy, procedure or public dataset for a specific jurisdiction and date. Distinguish written rules, implementation and lived access; give no personal legal or financial conclusion.

**Source types to locate:** official laws, rules and administrative guidance; audits, judgments and public service records; consented accounts from affected people and qualified specialists. These source types are not topic-specific sources already inspected.

#### BANK-434-007 — Gemstone chain of custody from mine to market

**Video question:** Gemstone chain of custody from mine to market: how do the rules and institutions work in a named jurisdiction?

**Coverage boundary:** Primary context: Gem Mining; branch: Trade accountability. Address Gemstone chain of custody from mine to market through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the responsible institutions, applicable date and jurisdiction for Gemstone chain of custody from mine to market.
- Trace a documented case or service journey from entry conditions to outcome, distinguishing rules from actual implementation.
- Compare access, costs, incentives and accountability for different affected groups.
- Check amendments, exceptions and competing interpretations; identify where qualified local guidance is required.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-434-008 — Labor conditions

**Video question:** Labor conditions: how do the rules and institutions work in a named jurisdiction?

**Coverage boundary:** Primary context: Gem Mining; branch: Trade accountability. Address Labor conditions through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the responsible institutions, applicable date and jurisdiction for Labor conditions.
- Trace a documented case or service journey from entry conditions to outcome, distinguishing rules from actual implementation.
- Compare access, costs, incentives and accountability for different affected groups.
- Check amendments, exceptions and competing interpretations; identify where qualified local guidance is required.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-434-009 — Origin claims and evidence limits

**Video question:** Origin claims and evidence limits: how do the rules and institutions work in a named jurisdiction?

**Coverage boundary:** Primary context: Gem Mining; branch: Trade accountability. Address Origin claims and evidence limits through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the responsible institutions, applicable date and jurisdiction for Origin claims and evidence limits.
- Trace a documented case or service journey from entry conditions to outcome, distinguishing rules from actual implementation.
- Compare access, costs, incentives and accountability for different affected groups.
- Check amendments, exceptions and competing interpretations; identify where qualified local guidance is required.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

## Relationship to neighboring niches

The following homes have deliberately related subject matter. They are navigation leads, not proof that the same question belongs in every bank. Choose one primary home for an actual episode and link it elsewhere. Where a subject appears in more than one context, retain the distinct case, population, system or interpretive question.

- [113 Energy & Power](../113_energy_power/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [114 Water](../114_water/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [157 Materials Science](../157_materials_science/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [158 Batteries & Energy Storage](../158_batteries_energy_storage/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [160 Data Centers & Infrastructure](../160_data_centers_infrastructure/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [161 Electricity & Electronics](../161_electricity_electronics/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.

## Production handoff

- Keep the BANK ID in notes. Refine the research question with an exact text edition, jurisdiction, population, product version, place, time range or clearly labeled fictional premise.
- Inspect actual sources; no source was verified by generating this map. Apply the existing registry planning and idea readiness process before project creation.
- Choose a current registered angle only after reading its niche-specific scope. This initial map has not checked or assigned angle plans for these entries.
- Keep Q1-Q42, CAT defaults, project snapshots, output locations and production gates unchanged. Catalog counts are not production or publication counts.
- Review neighboring banks for semantic overlap and follow the existing Phase 1 claim-ledger requirements. Add qualified review when required by the production contract.

## Open coverage

This initial map does not exhaust the niche, its regions, time periods, named case studies, texts, technical variants or disputed questions. It has not performed source-feasibility checks, semantic duplicate review of every pair, trend analysis, claim verification or episode production. Expand any category freely after identifying a real coverage gap; add categories where the subject requires them. Preserve existing IDs when refining wording and allocate new IDs only for genuinely new proposals.
