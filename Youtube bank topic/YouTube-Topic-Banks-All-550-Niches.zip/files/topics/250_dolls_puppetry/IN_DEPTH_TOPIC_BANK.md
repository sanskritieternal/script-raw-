# 250 Dolls & Puppetry: Subject Coverage and Episode Proposals

Updated: 2026-10-22 · **Initial subject map; proposed, not researched**

**3 subject categories · 10 topic proposals.**

A starting subject map for a Dolls & Puppetry YouTube channel. Categories organize concrete subtopics; each entry supplies an episode question, a research outline and a boundary for case selection. Counts follow the authored coverage, with no imposed topic maximum.

[All-niche index](../ALL_NICHE_TOPIC_BANKS.md) · [Editable JSON](./IN_DEPTH_TOPIC_BANK.json) · [Expansion method](../ALL_NICHE_EXPANSION_GUIDE.md)

This is a first coverage pass with concrete subject headings and research briefs. It has less editorial depth than the 120-question Meditation, Pranayama and Yoga pilots. It is not exhaustive, and has no fixed topic limit. The suggested research questions and outlines use domain-specific editorial patterns; they are proposals to refine against actual sources, not evidence that the research has been done.

The IDs refer to catalog entries, not episodes produced. Angles are deliberately unassigned until the actual niche angle scope and selected case are reviewed. No topic is ready_for_project or verified. The research outline is not a follow-along lesson, treatment plan, legal instruction, investment recommendation or hazardous procedure.

## Subject map

| Category | Research mode | Topic proposals |
|---|---|---:|
| CATALOG-250-01: Puppet traditions | history | 4 |
| CATALOG-250-02: Construction | technical | 3 |
| CATALOG-250-03: Ethics and adaptation | community | 3 |

## Detailed proposals

### Puppet traditions

**Research standard:** Compare dated primary records, material evidence and historical scholarship. Distinguish event dates, the dates of surviving witnesses, later retellings and disagreement. Do not invent quotations, intentions or an unbroken lineage.

**Source types to locate:** dated archival records and original publications; inscriptions, artifacts or photographs with provenance; critical editions and historical scholarship. These source types are not topic-specific sources already inspected.

#### BANK-250-001 — Kathputli communities

**Video question:** Kathputli communities: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Puppet traditions. Address Kathputli communities through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Kathputli communities in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-250-002 — Togalu gombeyaata shadow puppets

**Video question:** Togalu gombeyaata shadow puppets: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Puppet traditions. Address Togalu gombeyaata shadow puppets through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Togalu gombeyaata shadow puppets in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-250-003 — Bunraku ensemble performance

**Video question:** Bunraku ensemble performance: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Puppet traditions. Address Bunraku ensemble performance through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Bunraku ensemble performance in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-250-004 — Wayang kulit narrative contexts

**Video question:** Wayang kulit narrative contexts: what do contemporary records establish, and what remains uncertain?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Puppet traditions. Address Wayang kulit narrative contexts through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Locate Wayang kulit narrative contexts in a bounded time and place; build a chronology from identified records.
- Compare at least two independent witnesses or explain why only one survives.
- Analyze institutions, material conditions and overlooked participants rather than attributing everything to a single figure.
- Separate documented conclusions, interpretive debates and gaps that a reconstruction cannot resolve.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Construction

**Research standard:** Use the actual system documentation, a worked implementation and measurements. Identify inputs, outputs, constraints, tolerances, failure conditions and the limits of the example. Do not provide hazardous construction or unauthorized access procedures.

**Source types to locate:** original engineering papers; official versioned product or standards documentation; test reports and drawings with clear provenance. These source types are not topic-specific sources already inspected.

#### BANK-250-005 — Rod mechanisms

**Video question:** Rod mechanisms: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Construction. Address Rod mechanisms through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Rod mechanisms.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-250-006 — Joint articulation

**Video question:** Joint articulation: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Construction. Address Joint articulation through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Joint articulation.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-250-007 — Shadow-screen lighting

**Video question:** Shadow-screen lighting: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Construction. Address Shadow-screen lighting through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Shadow-screen lighting.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Ethics and adaptation

**Research standard:** Use consented participant accounts, local records and the community's own descriptions. Include differences of position, access and power; testimony is not a representative survey or clinical proof.

**Source types to locate:** consented interviews and oral histories; community publications and local records; field notes with method and consent documented. These source types are not topic-specific sources already inspected.

#### BANK-250-008 — Artisan attribution

**Video question:** Artisan attribution: how do participants describe the practice and its differences?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Ethics and adaptation. Address Artisan attribution through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Choose a specific community and identify who participates in Artisan attribution and who may be excluded.
- Document the actual routines, resources and relationships involved through more than one perspective.
- Compare change across generations, locations or life circumstances without assuming uniformity.
- Return to participants for context and consent checks; distinguish their views from the narrator's interpretation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-250-009 — Children's educational puppetry

**Video question:** Children's educational puppetry: how do participants describe the practice and its differences?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Ethics and adaptation. Address Children's educational puppetry through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Choose a specific community and identify who participates in Children's educational puppetry and who may be excluded.
- Document the actual routines, resources and relationships involved through more than one perspective.
- Compare change across generations, locations or life circumstances without assuming uniformity.
- Return to participants for context and consent checks; distinguish their views from the narrator's interpretation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-250-010 — Museum dolls versus living performance

**Video question:** Museum dolls versus living performance: how do participants describe the practice and its differences?

**Coverage boundary:** Primary context: Dolls & Puppetry; branch: Ethics and adaptation. Address Museum dolls versus living performance through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Choose a specific community and identify who participates in Museum dolls versus living performance and who may be excluded.
- Document the actual routines, resources and relationships involved through more than one perspective.
- Compare change across generations, locations or life circumstances without assuming uniformity.
- Return to participants for context and consent checks; distinguish their views from the narrator's interpretation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

## Relationship to neighboring niches

The following homes have deliberately related subject matter. They are navigation leads, not proof that the same question belongs in every bank. Choose one primary home for an actual episode and link it elsewhere. Where a subject appears in more than one context, retain the distinct case, population, system or interpretive question.

- [060 Symbols & Hidden Meanings](../060_symbols_hidden_meanings/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [243 Cultural Traditions](../243_cultural_traditions/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [244 Festivals Around the World](../244_festivals_around_the_world/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [245 Festival Origins](../245_festival_origins/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [246 Wedding Culture](../246_wedding_culture/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [247 Traditional Clothing](../247_traditional_clothing/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.

## Production handoff

- Keep the BANK ID in notes. Refine the research question with an exact text edition, jurisdiction, population, product version, place, time range or clearly labeled fictional premise.
- Inspect actual sources; no source was verified by generating this map. Apply the existing registry planning and idea readiness process before project creation.
- Choose a current registered angle only after reading its niche-specific scope. This initial map has not checked or assigned angle plans for these entries.
- Keep Q1-Q42, CAT defaults, project snapshots, output locations and production gates unchanged. Catalog counts are not production or publication counts.
- Review neighboring banks for semantic overlap and follow the existing Phase 1 claim-ledger requirements. Add qualified review when required by the production contract.

## Open coverage

This initial map does not exhaust the niche, its regions, time periods, named case studies, texts, technical variants or disputed questions. It has not performed source-feasibility checks, semantic duplicate review of every pair, trend analysis, claim verification or episode production. Expand any category freely after identifying a real coverage gap; add categories where the subject requires them. Preserve existing IDs when refining wording and allocate new IDs only for genuinely new proposals.
