# 302 Entrepreneurship: Subject Coverage and Episode Proposals

Updated: 2026-10-22 · **Initial subject map; proposed, not researched**

**3 subject categories · 9 topic proposals.**

A starting subject map for a Entrepreneurship YouTube channel. Categories organize concrete subtopics; each entry supplies an episode question, a research outline and a boundary for case selection. Counts follow the authored coverage, with no imposed topic maximum.

[All-niche index](../ALL_NICHE_TOPIC_BANKS.md) · [Editable JSON](./IN_DEPTH_TOPIC_BANK.json) · [Expansion method](../ALL_NICHE_EXPANSION_GUIDE.md)

This is a first coverage pass with concrete subject headings and research briefs. It has less editorial depth than the 120-question Meditation, Pranayama and Yoga pilots. It is not exhaustive, and has no fixed topic limit. The suggested research questions and outlines use domain-specific editorial patterns; they are proposals to refine against actual sources, not evidence that the research has been done.

The IDs refer to catalog entries, not episodes produced. Angles are deliberately unassigned until the actual niche angle scope and selected case are reviewed. No topic is ready_for_project or verified. The research outline is not a follow-along lesson, treatment plan, legal instruction, investment recommendation or hazardous procedure.

## Subject map

| Category | Research mode | Topic proposals |
|---|---|---:|
| CATALOG-302-01: Finding a business | finance | 3 |
| CATALOG-302-02: Economics | finance | 3 |
| CATALOG-302-03: Execution | technical | 3 |

## Detailed proposals

### Finding a business

**Research standard:** Use current official terms, filings or macroeconomic data; state jurisdiction, date, fees, taxes, risk, units and assumptions. Use transparent illustrative calculations rather than personal recommendations or return promises.

**Source types to locate:** regulator or official statistical publications; actual contracts, fee schedules and audited filings; original economic studies and disclosed calculation inputs. These source types are not topic-specific sources already inspected.

#### BANK-302-001 — Customer problem interviews

**Video question:** Customer problem interviews: which assumptions change the costs, risks and outcomes?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Finding a business. Address Customer problem interviews through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Specify the institution, product, market or household scenario behind Customer problem interviews, with date and jurisdiction.
- Work through a numerical example with explicit fees, cash flows and assumptions; label invented figures as illustrative.
- Stress-test a different price, income, rate or time horizon and identify who bears the risk.
- Compare official terms with common promotional claims and list the unresolved information a decision would require.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-302-002 — Demand validation

**Video question:** Demand validation: which assumptions change the costs, risks and outcomes?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Finding a business. Address Demand validation through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Specify the institution, product, market or household scenario behind Demand validation, with date and jurisdiction.
- Work through a numerical example with explicit fees, cash flows and assumptions; label invented figures as illustrative.
- Stress-test a different price, income, rate or time horizon and identify who bears the risk.
- Compare official terms with common promotional claims and list the unresolved information a decision would require.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-302-003 — Competitive alternatives

**Video question:** Competitive alternatives: which assumptions change the costs, risks and outcomes?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Finding a business. Address Competitive alternatives through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Specify the institution, product, market or household scenario behind Competitive alternatives, with date and jurisdiction.
- Work through a numerical example with explicit fees, cash flows and assumptions; label invented figures as illustrative.
- Stress-test a different price, income, rate or time horizon and identify who bears the risk.
- Compare official terms with common promotional claims and list the unresolved information a decision would require.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Economics

**Research standard:** Use current official terms, filings or macroeconomic data; state jurisdiction, date, fees, taxes, risk, units and assumptions. Use transparent illustrative calculations rather than personal recommendations or return promises.

**Source types to locate:** regulator or official statistical publications; actual contracts, fee schedules and audited filings; original economic studies and disclosed calculation inputs. These source types are not topic-specific sources already inspected.

#### BANK-302-004 — Contribution margins

**Video question:** Contribution margins: which assumptions change the costs, risks and outcomes?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Economics. Address Contribution margins through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Specify the institution, product, market or household scenario behind Contribution margins, with date and jurisdiction.
- Work through a numerical example with explicit fees, cash flows and assumptions; label invented figures as illustrative.
- Stress-test a different price, income, rate or time horizon and identify who bears the risk.
- Compare official terms with common promotional claims and list the unresolved information a decision would require.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-302-005 — Working capital

**Video question:** Working capital: which assumptions change the costs, risks and outcomes?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Economics. Address Working capital through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Specify the institution, product, market or household scenario behind Working capital, with date and jurisdiction.
- Work through a numerical example with explicit fees, cash flows and assumptions; label invented figures as illustrative.
- Stress-test a different price, income, rate or time horizon and identify who bears the risk.
- Compare official terms with common promotional claims and list the unresolved information a decision would require.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-302-006 — Cash runway

**Video question:** Cash runway: which assumptions change the costs, risks and outcomes?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Economics. Address Cash runway through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Specify the institution, product, market or household scenario behind Cash runway, with date and jurisdiction.
- Work through a numerical example with explicit fees, cash flows and assumptions; label invented figures as illustrative.
- Stress-test a different price, income, rate or time horizon and identify who bears the risk.
- Compare official terms with common promotional claims and list the unresolved information a decision would require.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

### Execution

**Research standard:** Use the actual system documentation, a worked implementation and measurements. Identify inputs, outputs, constraints, tolerances, failure conditions and the limits of the example. Do not provide hazardous construction or unauthorized access procedures.

**Source types to locate:** original engineering papers; official versioned product or standards documentation; test reports and drawings with clear provenance. These source types are not topic-specific sources already inspected.

#### BANK-302-007 — Testing a small offer

**Video question:** Testing a small offer: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Execution. Address Testing a small offer through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Testing a small offer.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-302-008 — Documenting repeatable operations

**Video question:** Documenting repeatable operations: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Execution. Address Documenting repeatable operations through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Documenting repeatable operations.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

#### BANK-302-009 — Choosing measurable launch criteria

**Video question:** Choosing measurable launch criteria: how does it work, and where do its design assumptions fail?

**Coverage boundary:** Primary context: Entrepreneurship; branch: Execution. Address Choosing measurable launch criteria through one bounded case, source set or experiment. Exclude an all-purpose survey of the whole niche; distinguish the case's findings from broader claims.

**Deep-dive research outline:**

- Map the components and operating conditions behind Choosing measurable launch criteria.
- Trace a worked example using a diagram, calculation or observed system; state all numerical assumptions.
- Compare an alternative design against the same requirements; include cost, reliability and accessibility where relevant.
- Examine a failure mode, measurement error or edge case and show what evidence would change the explanation.

**Next action:** Select and inspect a concrete case and traceable sources; record unresolved questions before choosing a registered angle and promoting an episode idea.

## Relationship to neighboring niches

The following homes have deliberately related subject matter. They are navigation leads, not proof that the same question belongs in every bank. Choose one primary home for an actual episode and link it elsewhere. Where a subject appears in more than one context, retain the distinct case, population, system or interpretive question.

- [103 Leadership & Management](../103_leadership_management/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [104 Corporate & Workplace](../104_corporate_workplace/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [105 Consumer Psychology](../105_consumer_psychology/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [106 Marketing & Advertising](../106_marketing_advertising/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [107 Retail & E-commerce](../107_retail_e-commerce/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.
- [108 Logistics & Supply Chain](../108_logistics_supply_chain/IN_DEPTH_TOPIC_BANK.md) — Related coverage cluster; inspect both scopes before creating a separate episode.

## Production handoff

- Keep the BANK ID in notes. Refine the research question with an exact text edition, jurisdiction, population, product version, place, time range or clearly labeled fictional premise.
- Inspect actual sources; no source was verified by generating this map. Apply the existing registry planning and idea readiness process before project creation.
- Choose a current registered angle only after reading its niche-specific scope. This initial map has not checked or assigned angle plans for these entries.
- Keep Q1-Q42, CAT defaults, project snapshots, output locations and production gates unchanged. Catalog counts are not production or publication counts.
- Review neighboring banks for semantic overlap and follow the existing Phase 1 claim-ledger requirements. Add qualified review when required by the production contract.

## Open coverage

This initial map does not exhaust the niche, its regions, time periods, named case studies, texts, technical variants or disputed questions. It has not performed source-feasibility checks, semantic duplicate review of every pair, trend analysis, claim verification or episode production. Expand any category freely after identifying a real coverage gap; add categories where the subject requires them. Preserve existing IDs when refining wording and allocate new IDs only for genuinely new proposals.
